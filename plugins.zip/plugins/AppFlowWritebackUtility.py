"""This module contains all necessary functions for the AppFlowWritebackUtility."""
# !/usr/bin/python
# -*- coding: utf-8 -*-
# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of this source code package.

__author__ = 'ZS ASSOCIATES'

# All the package imports
import traceback
import os
import time
import datetime
import subprocess
import sys
# import pydoop
from ExecutionContext import ExecutionContext
from LogSetup import logger
from PySparkUtility import PySparkUtility
from ConfigUtility import JsonConfigUtility
from CommonUtils import CommonUtils
from MySQLConnectionManager import MySQLConnectionManager
import CommonConstants as CommonConstants
import boto3

sys.path.insert(0, os.getcwd())

# All the global constants declarations
MODULE_NAME = 'AppFlowWritebackUtility'
PROCESS_NAME = 'Publish File to Salesforce'
CSV_FORMAT = "com.databricks.spark.csv"
SPARK_JOB_SUCCESS_DIR_NAME = '_SUCCESS'


# This class contains all the necessary functions for the AppFlowWritebackUtility
class AppFlowWritebackUtility(object):
    """This class contains all the necessary functions for the AppFlowWritebackUtility."""

    # initialization of class AppFlowWritebackUtility
    def __init__(self, execution_context=None):
        try:
            if not execution_context:
                self.execution_context = ExecutionContext()
                self.execution_context.set_context({"MODULE_NAME": MODULE_NAME,
                                                    "PROCESS_NAME": PROCESS_NAME})
            else:
                self.execution_context = execution_context
                self.execution_context.set_context({"MODULE_NAME": MODULE_NAME})
            self.configuration = JsonConfigUtility(
                CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)
            self.configuration = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
            self.audit_db = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
            self.sandbox_bckt = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "sandbox_bckt"])

        except KeyboardInterrupt:
            raise KeyboardInterrupt

        except Exception as e:
            error = "ERROR in " + self.execution_context.get_context_param("module_name") + \
                    " ERROR MESSAGE: " + str(traceback.format_exc())
            logger.error(error, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": error})
            # .error(error, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": ""})
            raise e

    def archive_files(self, bucket_nm, appflow_nm, prefix, target_location):
        status_message = "Starting Archival Process"
        logger.info(status_message, extra=self.execution_context.get_context())

        # Capturing Keys Present in Target Location
        client = boto3.client('s3')
        split_target = list(target_location.split('/'))
        tgt_bucket_nm = list(target_location.split('/'))[2]
        tgt_prefix = '/'.join(split_target[3:-1]) + '/'

        status_message = "Bucket Name of Target : " + str(tgt_bucket_nm) + ", Prefix is : " + str(
            tgt_prefix) + " and Appflow Name is " + str(appflow_nm)
        logger.info(status_message, extra=self.execution_context.get_context())
        status_message = "Bucket Name of Archival : " + str(bucket_nm) + ", Prefix is : " + str(
            prefix) + " and Appflow Name is " + str(appflow_nm)
        logger.info(status_message, extra=self.execution_context.get_context())
        response = client.list_objects_v2(Bucket=tgt_bucket_nm, Prefix=tgt_prefix)
        ls = response['Contents']
        header_file_nm = str(appflow_nm) + "_header.csv"
        try:
            for k in ls:
                if '.csv' in k['Key'] and header_file_nm not in k['Key']:
                    file_nm = k['Key'].split('/')[-1]
                    mv_cmd = "aws s3 mv s3://" + str(tgt_bucket_nm) + "/" + str(k['Key']) + " s3://" + str(
                        bucket_nm) + "/" + str(prefix) + " --sse 'AES256'"
                    status_message = "Move command for Archival : " + str(mv_cmd)
                    logger.info(status_message, extra=self.execution_context.get_context())
                    CommonUtils(self.execution_context).execute_shell_command(mv_cmd)
                    status_message = 'Executed s3 Move of File ' + str(file_nm) + 'to Archive Location successfully '
                    logger.debug(status_message, extra=self.execution_context.get_context())
            return 'Successfully Archived all Files '
        except Exception as e:
            error = "ERROR in " + self.execution_context.get_context_param("module_name") + " ERROR MESSAGE: " + \
                    str(traceback.format_exc())
            self.execution_context.set_context({"traceback": error})
            logger.error(error, extra=self.execution_context.get_context())
            raise e

    def remove_s3_files(self,target_location):
        status_message = "Removing all files apart from Header file from location : " + str(target_location)
        logger.info(status_message, extra=self.execution_context.get_context())
        del_cmd = 'aws s3 rm ' + str(target_location) + ' --recursive --exclude "*_header.csv"'
        try:
            CommonUtils(self.execution_context).execute_shell_command(del_cmd)
            status_message = 'Executed s3 delete of Files in location ' + str(target_location) + ' successfully'
            logger.info(status_message, extra=self.execution_context.get_context())
        except Exception as e:
            error = "ERROR in " + self.execution_context.get_context_param("module_name") + " ERROR MESSAGE: " + \
                    str(traceback.format_exc())
            status_message = 'Failed to execute s3 delete of Files in location ' + str(target_location)
            logger.info(status_message, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": error})
            logger.error(error, extra=self.execution_context.get_context())
            raise e

    def convert_to_csv(self, source_loc, target_loc):
        # Get spark and sql context
        spark_context = PySparkUtility().get_spark_context()

        split_source = list(source_loc.split('/'))
        bucket_nm = split_source[2]
        prefix = '/'.join(split_source[3:-1]) + '/'
        try:
            df1 = spark_context.read.parquet(source_loc)
            print("File is read in DF")
            client = boto3.client('s3')
            print("Bucket Name : " + str(bucket_nm) + " Prefix is " + str(prefix))
            response = client.list_objects_v2(Bucket=bucket_nm, Prefix=prefix)
            print(response)
            ls = response['Contents']
            siz = 0
            for k in ls:
                siz = siz + k['Size']

            siz = siz * 5
            no_of_part = (siz // (25 * 1000000)) + 1
            rw_cnt = df1.count()
            rows_chunck = (rw_cnt // no_of_part) + 1
            spark_context.conf.set("spark.sql.files.maxRecordsPerFile", rows_chunck)

            df1.write.format("csv").mode("append").option("sep", ",").option("quote", '"').option("header",
                                                                                                     "true").save(
                target_loc)
            return "Successfully Converted the Parquet to CSV"
        except Exception as e:
            error = "ERROR in " + self.execution_context.get_context_param("module_name") + " ERROR MESSAGE: " + \
                    str(traceback.format_exc())
            self.execution_context.set_context({"traceback": error})
            logger.error(error, extra=self.execution_context.get_context())
            raise e

    def logging_ext_insrt(self,cycle_id,geography_id,source_platform,src_system,database_name,object_name,load_type,target_location,insert_by,insert_date,update_by):

        status_message = "Inserting in log_ext_dataset_master"
        logger.info(status_message, extra=self.execution_context.get_context())
        start = datetime.datetime.now()
        start_time = start.strftime('%Y-%m-%d %H:%M:%S')
        status = "IN PROGRESS"
        end_time = "NULL"
        override_flag = "Y"
        comments = "Conversion from Parquet to CSV is Starting"
        curr_max_refresh_timestamp = "{}"
        prev_max_refresh_timestamp = "{}"
        record_count = 0  # needs to be changed
        output_file_format = "csv"
        output_file_name = 'null'
        source_file_location = 'null'
        query_description = "null"
        query_file_name = "none"
        query = 'null'
        incremental_load_column_name = 'none'
        query_insrt = "INSERT INTO " + "orchestration_db.log_ext_dataset_master" + " (geography_id, cycle_id, source_platform, src_system, database_name," \
                                                                                   "object_name, load_type, incremental_load_column_name," \
                                                                                   "query, query_file_name, query_description, source_file_location," \
                                                                                   "target_location, output_file_name, output_file_format, record_count," \
                                                                                   "prev_max_refresh_timestamp," \
                                                                                   "curr_max_refresh_timestamp, status, comments, load_start_time," \
                                                                                   "load_end_time,insert_by, insert_date, update_by," \
                                                                                   "update_date, override_flag) " + 'VALUES (' + '"' + str(
            geography_id) + '"' + ', ' + '"' + str(cycle_id) + '"' + ' , ' + '"' + str(
            source_platform) + '"' + ' , ' + '"' + str(
            src_system) + '"' + ' , ' + '"' + str(
            database_name) + '"' + ' , ' + '"' + str(
            object_name) + '"' + ' , ' + '"' + str(load_type) + '"' + ' , ' + '"' + str(
            incremental_load_column_name) + '"' + ' , ' + '"' + str(query) + '"' + ' , ' + '"' + str(
            query_file_name) + '"' + ' , ' + '"' + str(
            query_description) + '"' + ' , ' + '"' + str(
            source_file_location) + '"' + ' , ' + '"' + str(
            target_location) + '"' + ' , ' + '"' + str(
            output_file_name) + '"' + ' , ' + '"' + str(output_file_format) + '"' + ' , ' + '"' + str(
            record_count) + '"' + ' , ' + "'" + prev_max_refresh_timestamp + "'" + ' , ' + "'" + curr_max_refresh_timestamp + "'" + ' , ' + '"' + str(
            status) + '"' + ' , ' + '"' + str(
            comments) + '"' + ',' + '"' + start_time + '"' + ' , ' + '"' + end_time + '"' + ' , ' + '"' + str(
            insert_by) + '"' + ' , ' + '"' + str(insert_date) + '"' + ' , ' + '"' + str(
            update_by) + '"' + ' , ' + str(end_time) + ' , ' + '"' + str(override_flag) + '");'
        status_message = "Query to be executed : " + str(query_insrt)
        logger.info(status_message, extra=self.execution_context.get_context())
        try:
            result1 = MySQLConnectionManager().execute_query_mysql(query_insrt)
            status_message = "Insert in Log external dataset master successfull"
            logger.info(status_message, extra=self.execution_context.get_context())
            return status_message
        except Exception as e:
            error = "ERROR in " + self.execution_context.get_context_param("module_name") + " ERROR MESSAGE: " + \
                    str(traceback.format_exc())
            status_message = "Insert in Log external dataset master failed"
            logger.info(status_message, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": error})
            logger.error(error, extra=self.execution_context.get_context())
            raise e

    def logging_ext_upd(self,cycle_id,appflow_nm,message_response,end_time,status):
        status_message = "Updating log_ext_dataset_master"
        logger.info(status_message, extra=self.execution_context.get_context())
        message_response = message_response.replace('"', '')
        message_response = message_response.replace("'", '')
        query1 = "UPDATE " + "log_ext_dataset_master " + "SET " + "status = " + '"' + str(status) + '"' + ", " \
                 + "comments = " + '"' + str(message_response) + '"' + " , " + "load_end_time = " + '"' + str(end_time) + '"' +\
                 ',' + "update_date = " + '"' + str(end_time) + '"' + \
                 " where cycle_id = " + '"' + str(cycle_id) + ' " and object_name="' + str(appflow_nm) + '" and status = "IN PROGRESS" ;'
        status_message = "Query to be executed : " + str(query1)
        logger.info(status_message, extra=self.execution_context.get_context())

        try:
            result1 = MySQLConnectionManager().execute_query_mysql(query1)
            status_message = "Update in Log external dataset master successfull"
            logger.info(status_message, extra=self.execution_context.get_context())
            return status_message
        except Exception as e:
            error = "ERROR in " + self.execution_context.get_context_param("module_name") + " ERROR MESSAGE: " + \
                    str(traceback.format_exc())
            status_message = "Update in Log external dataset master failed"
            logger.info(status_message, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": error})
            logger.error(error, extra=self.execution_context.get_context())
            raise e

    def appflow_stat(self, appflow_nm, response):
        status_message = "Starting appflow " + response['executionId']
        logger.info(status_message, extra=self.execution_context.get_context())

        # Capture Execution ID For the AppFLow
        c = response['executionId']
        client = boto3.client('appflow', region_name='us-west-2')
        response1 = {}
        # time.sleep(120)
        a = 1
        while (a >= 0):
            status_message = "Checking appflow Status"
            logger.info(status_message, extra=self.execution_context.get_context())
            response1 = client.describe_flow(flowName=appflow_nm)
            sts = response1['lastRunExecutionDetails']['mostRecentExecutionStatus']
            if (sts == 'Successful' or sts == 'Error'):
                print(sts)
                status_message = "Appflow " + str(appflow_nm)
                logger.info(status_message, extra=self.execution_context.get_context())
                break
            else:
                print(sts)
                time.sleep(60)
        if sts == 'Successful':
            end = datetime.datetime.now()
            end_time = end.strftime('%Y-%m-%d %H:%M:%S')
            message_response = 'Flow ran Successfuly'
            # status_message = "Successfully Archived all the files"
            logger.info(message_response, extra=self.execution_context.get_context())
            return sts, message_response, end_time
        else:
            end = datetime.datetime.now()
            end_time = end.strftime('%Y-%m-%d %H:%M:%S')
            message_response = response1['lastRunExecutionDetails']['mostRecentExecutionMessage']
            # status_message = "Successfully Archived all the files"
            logger.info(message_response, extra=self.execution_context.get_context())
            return sts, message_response, end_time

    def trigger_appflow(self, dataset_id, freq):
        ### First Step is to capture the Appflow name, Publish Path and Target Path
        if len(dataset_id) == 0:
            raise Exception("Dataset Id is not provided")

        status_message = "Starting to prepare query for fetching Details for dataset id:" + str(dataset_id)
        logger.info(status_message, extra=self.execution_context.get_context())
        # Create Query to fetch Process_id, Object Name and Target Location
        fetch_query = "Select * from " + self.audit_db + ".ctl_ext_dataset_master where dataset_id='" + str(
            dataset_id) + "';"
        status_message = "Query to be Executed for extracting Details of Dataset Id:" + str(fetch_query)
        logger.info(status_message, extra=self.execution_context.get_context())
        ext_resultset = MySQLConnectionManager().execute_query_mysql(fetch_query, False)

        # Capture the Data Date & Cycle Id
        process_id = ext_resultset[0]['process_id']
        status_message = "Process ID for which Data date and Cycle Id are extracted :" + str(dataset_id)
        logger.info(status_message, extra=self.execution_context.get_context())
        data_date = CommonUtils().fetch_data_date_process(process_id, freq)
        data_date = str(data_date).replace("-", "")
        #data_date = '20210615'
        cycle_id = CommonUtils().fetch_cycle_id_for_data_date(process_id, freq, data_date)
        #cycle_id = '2021091006024125884'

        # Create Query to fetch and create Publish path
        fetch_pub_pth_query = "Select publish_s3_path from " + self.audit_db + ".ctl_dataset_master where dataset_id='" + str(
            dataset_id) + "';"
        status_message = "Query to be Executed for extracting Publish Path " + str(fetch_pub_pth_query)
        logger.info(status_message, extra=self.execution_context.get_context())
        ext_resultset_pub = MySQLConnectionManager().execute_query_mysql(fetch_pub_pth_query, False)
        # pub_pth_tmp=str(ext_resultset_pub[0]["publish_s3_path"])
        pub_pth = str(ext_resultset_pub[0]["publish_s3_path"]) + "pt_data_dt=" + str(
            data_date) + "/pt_cycle_id=" + str(cycle_id) + "/"
        status_message = "Target Location will be : " + str(pub_pth)
        logger.info(status_message, extra=self.execution_context.get_context())
        '''
        appflow_nm = ext_resultset[0]["object_name"]
        appflow_nm_I = appflow_nm + "_Insert"
        appflow_nm_U = appflow_nm + "_Update"
        load_type=ext_resultset[0]['load_type']
        appflw_nm_ls=[]
        if load_type == 'I/U':
            appflw_nm_ls.append(appflow_nm_I)
            appflw_nm_ls.append(appflow_nm_U)
        elif load_type == 'I':
            appflw_nm_ls.append(appflow_nm_I)
        else:
            appflw_nm_ls.append(appflow_nm_U)
        '''

        ### Call Method to Convert the Published File to CSV file
        for i in range(len(ext_resultset)):
            target_location = ext_resultset[i]["target_location"]
            appflow_nm = str(ext_resultset[i]["object_name"])
            messg_removal = self.remove_s3_files(target_location)
            # Call the function to Convert Publish Parquet File to CSV
            convrt_bool = self.convert_to_csv(pub_pth, target_location)

            ''' Logging Insert '''

            mess_log_insrt = self.logging_ext_insrt(cycle_id,ext_resultset[i]["geography_id"],ext_resultset[i]["source_platform"],
                                                    ext_resultset[i]["src_system"],ext_resultset[i]["database_name"],
                                                    appflow_nm,ext_resultset[i]["load_type"],
                                                    ext_resultset[i]["target_location"],ext_resultset[i]["insert_by"],
                                                    ext_resultset[i]["insert_date"],ext_resultset[i]["update_by"])

            ### Trigger Appflow For the Writeback
            # Checking if Appflow is Present

            client = boto3.client('appflow', region_name='us-west-2')
            list_of_flows_present = []
            list_flows_response = client.list_flows(maxResults=99)
            for each in list_flows_response['flows']:
                list_of_flows_present.append(each['flowName'])
            if appflow_nm not in list_of_flows_present:
                status_message = "Appflow " + str(appflow_nm) + " is not present in AWS AppFlow Service"
                logger.info(status_message, extra=self.execution_context.get_context())
                logger.error(status_message, extra=self.execution_context.get_context())
                raise Exception

            status_message = "Appflow Name is " + appflow_nm
            logger.info(status_message, extra=self.execution_context.get_context())
            response = client.start_flow(flowName=appflow_nm)
            time.sleep(30)
            status, message_response, end_time= self.appflow_stat(appflow_nm, response)

            # Update the Bucket Name to be pulled from Common Constants
            #status = "Successful"
            #bucket_nm = 'northstar-gilead-us-west-2-s3-sandbox-dev'
            bucket_nm = self.sandbox_bckt
            prefix = 'G360_Writeback_Archive/' + str(appflow_nm) + "/pt_data_dt=" + str(data_date) + "/pt_cycle_id=" + str(
                cycle_id) + "/"

            if status == "Successful":
                # end = datetime.now()
                mess_log_upd=self.logging_ext_upd(cycle_id,appflow_nm,message_response,end_time,status)
                messg_archive = self.archive_files(bucket_nm, appflow_nm, prefix, target_location)
                status_message = "Successfully Archived all the files"
                logger.info(status_message, extra=self.execution_context.get_context())
                message = 'Status:Success:Message:Appflow execution process was success'
                #return message

            else:
                mess_log_upd = self.logging_ext_upd(cycle_id, appflow_nm, message_response,
                                                    end_time, status)
                status_message = "Appflow " + str(appflow_nm) + " Failed, Archiving Files now"
                logger.info(status_message, extra=self.execution_context.get_context())
                messg_archive = self.archive_files(bucket_nm, appflow_nm, prefix, target_location)
                status_message = "Successfully Archived all the files"
                logger.info(status_message, extra=self.execution_context.get_context())
                message = 'Status:Failed:Message:Appflow execution process Failed'
                #return message
        return "Successfully Completed"

if __name__ == '__main__':
    dataset_id = sys.argv[1]
    freq = sys.argv[2]
    writeback = AppFlowWritebackUtility()
    return_message = writeback.trigger_appflow(dataset_id, freq)
