import time
import boto3
import os
import requests
import base64
import json
import datetime
import os
import sys
import subprocess
import multiprocessing
from datetime import datetime ,timedelta
import logging
import pandas as pd
import CommonConstants as CommonConstants
import shutil
sys.path.insert(1,CommonConstants.AIRFLOW_CODE_PATH )
from MySQLConnectionManager import MySQLConnectionManager


MODULE_NAME = 'AppFlowUtility'
PROCESS_NAME = 'Execution of Appflow'


logger = logging.getLogger(__name__)
hndlr = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
hndlr.setFormatter(formatter)
logger.setLevel("DEBUG")
logger.addHandler(hndlr)


class Appflow_automation():
    """
    Class contains all the functions related to Appflow automation
    """
    def __init__(self, d ):
        self.d = d
        self.audit_db = "orchestration_db"
        self.process_log_table_name = "ctl_ext_dataset_master"
        #self.execution_context = ExecutionContext()
        #self.execution_context.set_context({"MODULE_NAME": MODULE_NAME,"PROCESS_NAME": PROCESS_NAME})


    def execute(self,appfl_name,response):
        status_message = "Starting appflow " +response['executionId']
        logger.info(status_message)
        status_message='find above the execution id'
        logger.info(status_message)
        c = response['executionId']

        client = boto3.client('appflow', region_name='us-west-2')

        response1={}
        #time.sleep(120)
        a = 1
        while(a>=0):
            response1 = client.describe_flow(flowName= appfl_name)
            sts = response1['lastRunExecutionDetails']['mostRecentExecutionStatus']
            if (sts =='Successful' or sts =='Error'):
                print(sts)
                break
            else:
                print(sts)
                time.sleep(60)
        if sts=='Successful':
            bucket_name = response1['destinationFlowConfigList'][0]['destinationConnectorProperties']['S3']['bucketName']
            bucket_folders = response1['destinationFlowConfigList'][0]['destinationConnectorProperties']['S3']['bucketPrefix']
            final_path = 'aws s3 ls s3://' + bucket_name + '/' + bucket_folders + '/' + appfl_name + '/'
            message_response='Flow ran Successfuly'

            file = os.popen(final_path).read()
            list_file = list(file.split("\n"))
            s = str(list_file)
            s1 = s.split(' ')

            for i in s1:
                if (i.find(c) == -1):
                    print("NO")
                else:
                    #print("YES")
                    #print("execution Id :", c)
                    print("File Created :", i)
                    break
            print(i[:-2])
            return i[:-2],sts,bucket_name,bucket_folders,appfl_name,message_response
        else:
            bucket_name=''
            bucket_folders=''
            i=''
            appfl_name=''
            message_response=response1['lastRunExecutionDetails']['mostRecentExecutionMessage']
            return i,sts,bucket_name,bucket_folders,appfl_name,message_response


    def database(self):
        query_str = "Select target_location,process_id,object_name,source_platform,src_system,database_name,load_type,insert_by,insert_date,update_by,update_date,geography_id  from {audit_db}.{process_log_table_name} where process_id ={process_id} and source_platform='salesforce'"
        query = query_str.format(audit_db=self.audit_db,
                                 process_log_table_name=self.process_log_table_name,
                                 process_id=self.d)
        #logger.info("Query:",query)
        result = MySQLConnectionManager().execute_query_mysql(query)
        print(result)
        return(result)

    def final_pool(self,database_op):
        start = datetime.now()
        start_time = start.strftime('%Y-%m-%d %H:%M:%S')
        status = "IN PROGRESS"
        end_time = "null"
        cycle_id = start.strftime('%Y%m%d%H%M%S%f')
        override_flag = "Y"
        comments = "Flow in progress"
        curr_max_refresh_timestamp = "{}"
        prev_max_refresh_timestamp = "{}"
        record_count = 0   #needs to be changed
        output_file_format = "txt"
        output_file_name = 'null'
        source_file_location = 'null'
        query_description = "select * from"
        query_file_name = "none"
        query = 'null'
        incremental_load_column_name = 'none'
        query = "INSERT INTO " +"orchestration_db.log_ext_dataset_master"+" (geography_id, cycle_id, source_platform, src_system, database_name,"\
                                                "object_name, load_type, incremental_load_column_name,"\
                                                "query, query_file_name, query_description, source_file_location,"\
                                                "target_location, output_file_name, output_file_format, record_count,"\
                                                "prev_max_refresh_timestamp,"\
                                                "curr_max_refresh_timestamp, status, comments, load_start_time,"\
                                                "load_end_time,insert_by, insert_date, update_by,"\
                                                "update_date, override_flag) " + 'VALUES (' + '"' + str(database_op['geography_id']) + '"' + ', ' + '"' + str(cycle_id) + '"' + ' , ' + '"' + str(
            database_op['source_platform']) + '"' + ' , ' + '"' + str(database_op['src_system']) + '"' + ' , ' + '"' + str(
            database_op['database_name']) + '"' + ' , ' + '"' + str(
            database_op['object_name']) + '"' + ' , ' + '"' + str(database_op['load_type']) + '"' + ' , ' + '"' + str(
            incremental_load_column_name) + '"' + ' , ' + '"' + str(query) + '"' + ' , ' + '"' + str(
            query_file_name) + '"' + ' , ' + '"' + str(
            query_description) + '"' + ' , ' + '"' + str(
            source_file_location) + '"' + ' , ' + '"' + str(
            database_op['target_location']) + '"' + ' , ' + '"' + str(
            output_file_name) + '"' + ' , ' + '"' + str(output_file_format) + '"' + ' , ' + '"' + str(
            record_count) + '"' + ' , ' + "'" + prev_max_refresh_timestamp + "'" + ' , ' + "'" + curr_max_refresh_timestamp + "'" + ' , ' + '"' + str(
            status) + '"' + ' , ' + '"' + str(
            comments) + '"' + ',' + '"' + start_time + '"' + ' , ' + '"' + end_time + '"' + ' , ' + '"' + str(
            database_op['insert_by']) + '"' + ' , ' + '"' + str(database_op['insert_date']) + '"' + ' , ' + '"' + str(
            database_op['update_by']) + '"' + ' , '  + str(end_time)  + ' , ' + '"' + str(override_flag) + '");';
        logger.info("Inserting the query")
        result1 = MySQLConnectionManager().execute_query_mysql(query)


        client = boto3.client('appflow', region_name='us-west-2')
        #list_of_flows_present=[]
        #list_flows_response=client.list_flows(maxResults=99)
        #for each in list_flows_response['flows']:
        #    list_of_flows_present.append(each['flowName'])

        #if database_op['object_name'] not in list_of_flows_present:
        #    query_update = "UPDATE log_ext_dataset_master SET " + " status = 'FAILED'" + ", " + "comments = " + '"'+'Appflow is not present' +'"'+" where cycle_id = " +'"'+str(cycle_id)+'"'
        #    MySQLConnectionManager().execute_query_mysql(query_update)

        try:
            describe_flow_output=client.describe_flow(flowName= database_op['object_name'])
        except:
            query_update = "UPDATE log_ext_dataset_master SET " + " status = 'FAILED'" + ", " + "comments = " + '"'+'Appflow is not present' +'"'+" where cycle_id = " +'"'+str(cycle_id)+'"'
            MySQLConnectionManager().execute_query_mysql(query_update)
            print("Appflow",database_op['object_name'],"not present.")
            return
        
        if describe_flow_output['tasks'][0]['taskType']=='Filter' and bool(describe_flow_output['tasks'][0]['taskProperties']):
            check_last_date_query='select curr_max_refresh_timestamp from orchestration_db.log_ext_dataset_master where cycle_id=(select max(cycle_id) from orchestration_db.log_ext_dataset_master where object_name="{appflow_to_be_updated}" and status="SUCCEDED") and object_name="{appflow_to_be_updated}"'
            check_last_date_query=check_last_date_query.format(appflow_to_be_updated=database_op['object_name'])
            result_time = MySQLConnectionManager().execute_query_mysql(check_last_date_query)
            #result_time=json.loads(result_time[0]['curr_max_refresh_timestamp'])
            if bool(result_time):
                result_time=json.loads(result_time[0]['curr_max_refresh_timestamp'])
                if bool(result_time):
                    print('Entered')
                    result_time=result_time['time']
                    result_time=datetime.strptime(result_time,'%Y-%m-%d %H:%M:%S')
                    result_time=result_time-timedelta(days=1)
                    result_time=result_time.timestamp()
                    result_time=str(result_time)[:-2]+'000'
                    if describe_flow_output['triggerConfig']['triggerType'] == 'OnDemand':
                        triggerConfig_param={'triggerType': 'OnDemand'}
                    else:
                        triggerConfig_param=describe_flow_output['triggerConfig']
                    tasks_param=describe_flow_output['tasks']

                    tasks_param[0]['taskProperties']['VALUE']=str(result_time)
                    client.update_flow(flowName= describe_flow_output['flowName'],triggerConfig=triggerConfig_param,sourceFlowConfig=describe_flow_output['sourceFlowConfig'], destinationFlowConfigList=describe_flow_output['destinationFlowConfigList'],tasks=tasks_param)
            response= client.start_flow(flowName=database_op['object_name'])
            time.sleep(30)

        else:
            response = client.start_flow(flowName=database_op['object_name'])
            time.sleep(30)
        appfl, status, bucket , folder , appflow_name ,message_response = appflow_utility.execute(database_op['object_name'],response)

        if (status == "Successful"):
            end = datetime.now()
            end_time = end.strftime('%Y-%m-%d %H:%M:%S')
            file_write_time=str(end.strftime('%Y%m%d%H%M%S'))
            cmnt = message_response
            process_status = "SUCCEDED"
            source_file_loc='s3://'+bucket+'/'+folder+'/'+appflow_name+'/'+appfl
            destination_file='s3://'+bucket+'/'+folder+'/'+appflow_name+'/'+appflow_name+'_'+file_write_time+'.csv'

            try:
                copy_command='aws s3 cp '+source_file_loc+' '+ destination_file
                copy_command_response=subprocess.Popen(copy_command, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
                output,error = copy_command_response.communicate()
                if copy_command_response.returncode==0:
                    status_message = "Completed executing command to copy data file"
                    logger.info(status_message)
                    try:
                        delete_command = 'aws s3 rm '+source_file_loc
                        delete_command_response = subprocess.Popen(delete_command, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
                        output,error = delete_command_response.communicate()
                        if delete_command_response.returncode == 0:
                            status_message = "Completed executing command to delete data file"
                            logger.info(status_message)
                        else:
                            status_message = "deleting failed while executing command " + delete_command
                            raise Exception(status_message)
                    except Exception as Exception:
                        status_message="Deleting file Failed"
                        logger.error(status_message)
                        raise Exception
                else:
                    status_message="copy command failed " + copy_command
                    raise Exception(status_message)
            except Exception as Exception:
                status_message="Copy file failed"
                logger.error(status_message)
                raise Exception

            appfl=describe_flow_output['flowName']+'_'+file_write_time+'.csv'
            final_file_written=database_op['target_location']+appfl
            print(final_file_written)
            max_timestamp={}
            max_timestamp=json.dumps(max_timestamp)
            count_of_records=0


            query1 = "UPDATE " + "log_ext_dataset_master " + "SET " + "record_count="+'"'+str(count_of_records)+'"'+ " , curr_max_refresh_timestamp=" +"'"+max_timestamp+"'" +" , status = " +'"' + process_status +'"'+ ", " + "comments = " + '"'+cmnt +'"'+" ," + "output_file_name = "+ '"'+str(appfl)+'"'+','+"load_end_time = "+'"'+str(end_time)+'"'+','+"update_date = "+'"'+str(end_time)+'"'+" where cycle_id = " +'"'+cycle_id+'"'
            print(query1)
            result2 = MySQLConnectionManager().execute_query_mysql(query1)

            return appfl
        else:
            cmnt=message_response
            cmnt=cmnt.replace('"','')
            cmnt=cmnt.replace("'",'')
            query_update = "UPDATE log_ext_dataset_master SET " + " status = 'FAILED'" + ", " + "comments = " + '"'+str(cmnt) +'"'+" where cycle_id = " +'"'+str(cycle_id)+'"'
            MySQLConnectionManager().execute_query_mysql(query_update)


    def update_logs(self,database_result):
        for each in database_result:
            appflow_nm=each['object_name']
            logger.info(appflow_nm)
            query='select target_location,output_file_name,status,cycle_id from orchestration_db.log_ext_dataset_master where object_name = ' + '"' +str(appflow_nm) + '"'+' and cycle_id = (select max(cycle_id) from orchestration_db.log_ext_dataset_master where object_name = '+'"'+str(appflow_nm)+'")'

            result_query=MySQLConnectionManager().execute_query_mysql(query)
            status_run=result_query[0]['status']


            if status_run=='SUCCEDED':
                logger.info('success entry')
                cycle_id=result_query[0]['cycle_id']
                location=result_query[0]['target_location']
                file_name=result_query[0]['output_file_name']
                client=boto3.client('appflow', region_name='us-west-2')
                describe_output=client.describe_flow(flowName=appflow_nm)

                if describe_output['tasks'][0]['taskType']== 'Filter' and bool(describe_output['tasks'][0]['taskProperties']):
                    filter_column=describe_output['tasks'][0]['sourceFields'][0]
                    pth=CommonConstants.AIRFLOW_CODE_PATH
                    logger.info(pth)
                    pth=pth+'/'+'appflow_files'+'/'+describe_output['flowName']
                    logger.info(pth)
                    if not os.path.isdir(pth):
                        logger.info("entered")
                        os.mkdir(pth)
                        logger.info("exiting")

                    file_written = pth+'/'+file_name
                    logger.info(file_written)
                    cp_cmd='aws s3 cp '+ location+file_name + ' ' + file_written
                    logger.info(cp_cmd)
                    copy_response=subprocess.Popen(cp_cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
                    output,error=copy_response.communicate()
                    logger.info(copy_response.returncode)
                    if copy_response.returncode==0:
                        print('In loop')
                        max_timestamp=''
                        no_of_records=0
                        for df in pd.read_csv(file_written,iterator=True,chunksize=10000):
                            df=df.where(df.notnull(),'')
                            timestamp_value=df[filter_column].max()
                            if max_timestamp < timestamp_value:
                                max_timestamp=timestamp_value
                            no_of_records=no_of_records+len(df.index)
                        max_timestamp=max_timestamp.replace('T',' ')
                        max_timestamp=max_timestamp[:19]
                        max_timestamp={'time':max_timestamp}
                        max_timestamp=json.dumps(max_timestamp)
                        count_of_records=no_of_records

                        query="UPDATE log_ext_dataset_master SET record_count="+'"'+str(count_of_records)+'"'+ " , curr_max_refresh_timestamp=" +"'"+max_timestamp+"'" +" where cycle_id = " +'"'+str(cycle_id)+'"'
                        result_query=MySQLConnectionManager().execute_query_mysql(query)
                        logger.info(result_query)

                        if os.path.isdir(pth):
                            logger.info("Removing the path created for the appflow :")
                            shutil.rmtree(pth,ignore_errors=True)
                else:
                    pth=CommonConstants.AIRFLOW_CODE_PATH
                    logger.info(pth)
                    pth=pth+'/'+'appflow_files'+'/'+describe_output['flowName']
                    logger.info(pth)
                    if not os.path.isdir(pth):
                        logger.info("entered")
                        os.mkdir(pth)
                        logger.info("exiting")

                    
                    file_written = pth+'/'+file_name
                    logger.info(file_written)
                    cp_cmd='aws s3 cp '+ location+file_name + ' ' + file_written
                    logger.info(cp_cmd)
                    copy_response=subprocess.Popen(cp_cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
                    output,error=copy_response.communicate()
                    logger.info(copy_response.returncode)
                    if copy_response.returncode==0:
                        print('In loop')
                        no_of_records=0
                        for df in pd.read_csv(file_written,iterator=True,chunksize=10000):
                            no_of_records=no_of_records+len(df.index)
                        count_of_records=no_of_records

                        query="UPDATE log_ext_dataset_master SET record_count="+'"'+str(count_of_records)+'"'+ " where cycle_id = " +'"'+str(cycle_id)+'"'
                        result_query=MySQLConnectionManager().execute_query_mysql(query)
                        logger.info(result_query)

                        if os.path.isdir(pth):
                            logger.info("Removing the path created for the appflow :")
                            shutil.rmtree(pth,ignore_errors=True)


def main():
    try:
        database_op = appflow_utility.database()
        if len(database_op)==0:
            raise Exception("process_id is not valid")
        print(database_op)
        print("++++++++++++++++++++++++++++++++++")
        pool = multiprocessing.Pool()
        print("created pool")
        outputs = pool.map(appflow_utility.final_pool, database_op)
        appflow_utility.update_logs(database_op)
        print(outputs)
        message='Status:Success:Message:Appflow execution script was success. Check log_ext_dataset_master for per dataset details'
        return message

    except Exception as e:
        print(e)
        e=str(e)
        message='Status:Fail:Message:'+e
        raise message

if __name__ == '__main__':
    process_id = sys.argv[1]
    appflow_utility = Appflow_automation(process_id)
    message=main()
    sys.stdout.write(message)
