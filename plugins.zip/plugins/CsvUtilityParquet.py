import os
import sys
import datetime
import re
import sys
from MySQLConnectionManager import MySQLConnectionManager
import boto3
import CommonConstants
from ConfigUtility import JsonConfigUtility
import pyspark
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
sc = SparkContext('local')
spark = SparkSession(sc)

class CsvUtility:
    today = datetime.date.today() - datetime.timedelta(days=datetime.date.today().weekday())
    today = str(today).replace("-", "")
    print(today)
    s3 = boto3.resource('s3')
    s3_client = boto3.client('s3')
    configuration = JsonConfigUtility(
            CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)
    audit_db = configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
    process_id = sys.argv[1]
    qry_file_name_list = "select table_s3_path, staging_location, dataset_name, dataset_type, document_link, tags from ctl_dataset_master where dataset_id={dataset_id} ".format(dataset_id=process_id)
    file_name_list = MySQLConnectionManager().execute_query_mysql(qry_file_name_list)
    print(file_name_list)
    table_loc=file_name_list[0]['table_s3_path']
    stage_loc=file_name_list[0]['staging_location']
    dataset_name=file_name_list[0]['dataset_name']
    dataset_type=file_name_list[0]['dataset_type']
    document_link=file_name_list[0]['document_link']
    tgt_file_name=file_name_list[0]['tags']
    print (table_loc)
    print (stage_loc)
    print (dataset_name)
    print (dataset_type)
    print (document_link)
    print (tgt_file_name)
    if dataset_type=='processed':
        log_dtl="select cycle_id, data_date, cycle_status from log_cycle_dtl where process_id= ( select process_id from ctl_process_dependency_master where dataset_id={dataset_id} and table_type='Target') and cycle_id=(select max(cycle_id) from log_cycle_dtl where process_id=( select process_id from ctl_process_dependency_master where dataset_id={dataset_id} and table_type='Target') and cycle_status in ('SUCCEEDED')) ".format(dataset_id=process_id)
        log_dtl_list = MySQLConnectionManager().execute_query_mysql(log_dtl)
        cycle_id=log_dtl_list[0]['cycle_id']
        data_date=log_dtl_list[0]['data_date']
        status=log_dtl_list[0]['cycle_status']
        print (cycle_id)
        print (data_date)
        print(status)
    elif dataset_type=='raw':
        log_dtl="select file_id, batch_id from log_file_smry where dataset_id={dataset_id} and batch_id=(select max(batch_id) from log_file_smry where dataset_id={dataset_id}) and file_id=(select max(file_id) from log_file_smry where dataset_id={dataset_id} ) and file_status='SUCCEEDED'".format(dataset_id=process_id)
        log_dtl_list = MySQLConnectionManager().execute_query_mysql(log_dtl)
        batch_id=log_dtl_list[0]['batch_id']
        file_id=log_dtl_list[0]['file_id']
        print (batch_id)
        print (file_id)
    columns_dtl = "select column_name from ctl_column_metadata where dataset_id={dataset_id} and column_tag='Y'".format(dataset_id=process_id)
    columns_dtl_list = MySQLConnectionManager().execute_query_mysql(columns_dtl)
    column_name=columns_dtl_list[0]['column_name']
    list_of_columns = []
    for i in columns_dtl_list:
        print(i['column_name'])
        list_of_columns.append(i['column_name'])
    print(list_of_columns)

    path=''
    if dataset_type=='processed':
        if table_loc[-1] != '/':
            path=table_loc+'/pt_data_dt='+str(data_date).replace('-','')+'/pt_cycle_id='+str(cycle_id)
        else:
            path=table_loc+'pt_data_dt='+str(data_date).replace('-','')+'/pt_cycle_id='+str(cycle_id)
    elif dataset_type=='raw':
        if stage_loc[-1] != '/':
            path=stage_loc+'/pt_batch_id='+str(batch_id)+'/pt_file_id='+str(file_id)
        else:
            path=stage_loc+'pt_batch_id='+str(batch_id)+'/pt_file_id='+str(file_id)
    print(path)
    #df = spark.read.options(inferSchema='True',delimiter='|',header=True).csv(path)
    df = spark.read.parquet(path)
    df.show(1)
    target_location=document_link
    if(list_of_columns!=None):
        df=df.select(list_of_columns)
    df.repartition(1).write.option("header",True).option("delimiter","|").csv(target_location+"test", mode="overwrite")
    #Splitting the S3 path by '/'
    bucketsplitter=target_location.split('/')
    #Extracting bucket name
    bucket_name=bucketsplitter[2]
    #Extracting key from path
    key_splitter=target_location.split('/',3)
    key=key_splitter[3]
    print(bucket_name)
    print(key)
    print("+++++++++")
    res = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=key+'test/', MaxKeys=2)
    #print(res)
    if 'Contents' in res:
        keys = res['Contents']
        print(keys)
        print('s3://' + bucket_name+ '/'+ res['Contents'][1]['Key'])
        for i in keys:
            print(i['Key'])
            if 'part' in i['Key']:
                src = 's3://' + bucket_name+ '/'+ i['Key']
                tgt_ec2 = '/tmp/csv/'
                tgt = 's3://' + bucket_name+ '/'+ key + tgt_file_name + '_' + today + '.csv'
                print("+++++")
                print(src)
                print(tgt)
                cpy_command='aws s3 cp '+src+' '+tgt
                cpy_command_1='aws s3 cp '+tgt_ec2+' '+tgt
                delete_src=src.rsplit('/',1)
                delete_command='aws s3 rm '+delete_src[0]+'/ --recursive'
                print(delete_src)
                os.system(cpy_command)
        os.system(delete_command)
