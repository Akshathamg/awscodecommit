from MySQLConnectionManager import MySQLConnectionManager
from HiveToHDFSHandler import HiveToHDFSHandler
import CommonConstants as CommonConstants
from ConfigUtility import JsonConfigUtility
from pyspark.sql.functions import *
from datetime import datetime
from datetime import timedelta
from functools import reduce
import time
import MySQLdb
import logging
import subprocess
import os
import sys

def get_previous_hist(spark,target_tablename):
    try:
        current_datetime = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        spark.sql("""set hive.exec.dynamic.partition.mode=nonstrict""")
        
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        
        # data_date = datetime.strptime(data_dt, '%Y%m%d').strftime('%Y-%m-%d')
        target_tablename = target_tablename.lower()
        
        #Establish a connection with the mySQL db
        logger.info("Starting to Establish MySQL Database Connection")
        
        configuration = JsonConfigUtility(CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)
        audit_db = configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
        
        mysql_connection= MySQLConnectionManager().get_my_sql_connection()
        cursor = mysql_connection.cursor(MySQLdb.cursors.DictCursor)
        
        ###Fetch the dataset id for the target table
        cursor.execute("select dataset_id, table_s3_path, table_hdfs_path, table_partition_by from {orchestration_db_name}.ctl_dataset_master where trim(lower(table_name)) = trim(lower('{target_tablename}'))".format(
        orchestration_db_name=audit_db, 
        target_tablename = target_tablename
        ))
        
        logger.info("Connection to MySQL Database Established Successfully")
        
        dataset_result  = cursor.fetchone()
        
        if dataset_result is None:
            status_message = "No entry present in databse with table_name = {target_tablename}".format(target_tablename=target_tablename)
            raise Exception(status_message)
        
        ###Fetch the latest successful cycle id for the previous data date
        cursor.execute("select cycle_id,data_date from (select a.*,b.dataset_id from {orchestration_db_name}.log_cycle_dtl a inner join orchestration_db.ctl_process_dependency_details b on b.dataset_id = '{dataset_id}' and lower(b.table_type)='target' and a.process_id = b.process_id and trim(lower(a.cycle_status)) = 'succeeded')c order by cycle_start_time desc limit 1".format(
        orchestration_db_name=audit_db, 
        dataset_id=dataset_result['dataset_id']
        ))
        
        fetch_enable_flag_result = cursor.fetchone()
        
        if fetch_enable_flag_result is not None:
            #Creating the source and target path using the table path, cycle id, and data date
            
            s3_data_copy_path = str(dataset_result['table_s3_path']).rstrip('/') + '/pt_data_dt=' + str(fetch_enable_flag_result['data_date']).replace("-","") + "/pt_cycle_id=" + str(fetch_enable_flag_result['cycle_id']) + "/"
            
            logger.info("S3 Path:"+s3_data_copy_path) 
            
            # copy data to hdfs using the path generated above, in case it does not copy log the process failure
            try:
                df_return = spark.read.parquet(s3_data_copy_path)
            except Exception as ex:
                status_message="Copying Failed while copying from s3 location {s3_data_copy_path}".format(s3_data_copy_path=s3_data_copy_path)
                logger.error(status_message)
                raise Exception(status_message)
            
            return df_return
        
        #msck repair of target table
        string_query = "msck repair table {target_tablename}".format(target_tablename=target_tablename)
        spark.sql(string_query)
        
        df_return = spark.sql("""select * from {target_tablename} where pt_cycle_id = (select max(pt_cycle_id) from {target_tablename})""".format(target_tablename=target_tablename))
        return df_return
        
    except Exception as ex:
        print(str(ex))
        raise ex
        
def get_previous_hist_with_dt(spark,target_tablename,data_dt):
    try:
        curr_date = datetime.strptime(data_dt, '%Y%m%d').date()
        prev_date = curr_date - timedelta(days = 1)

        current_datetime = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        spark.sql("""set hive.exec.dynamic.partition.mode=nonstrict""")
        
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        
        # data_date = datetime.strptime(data_dt, '%Y%m%d').strftime('%Y-%m-%d')
        target_tablename = target_tablename.lower()
        
        #Establish a connection with the mySQL db
        logger.info("Starting to Establish MySQL Database Connection")
        
        configuration = JsonConfigUtility(CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)
        audit_db = configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
        
        mysql_connection= MySQLConnectionManager().get_my_sql_connection()
        cursor = mysql_connection.cursor(MySQLdb.cursors.DictCursor)
        
        ###Fetch the dataset id for the target table
        cursor.execute("select dataset_id, table_s3_path, table_hdfs_path, table_partition_by from {orchestration_db_name}.ctl_dataset_master where trim(lower(table_name)) = trim(lower('{target_tablename}'))".format(
        orchestration_db_name=audit_db, 
        target_tablename = target_tablename
        ))
        
        logger.info("Connection to MySQL Database Established Successfully")
        
        dataset_result  = cursor.fetchone()
        
        if dataset_result is None:
            status_message = "No entry present in databse with table_name = {target_tablename}".format(target_tablename=target_tablename)
            raise Exception(status_message)
        
        ###Fetch the latest successful cycle id for the previous data date
        cursor.execute("select cycle_id,data_date from (select a.*,b.dataset_id from {orchestration_db_name}.log_cycle_dtl a inner join orchestration_db.ctl_process_dependency_details b on b.dataset_id = '{dataset_id}' and lower(b.table_type)='target' and a.process_id = b.process_id and a.data_date = '{prev_date}' and trim(lower(a.cycle_status)) = 'succeeded')c order by cycle_start_time desc limit 1".format(
        orchestration_db_name = audit_db, 
        dataset_id = dataset_result['dataset_id'],
        prev_date = prev_date
        ))
        
        fetch_enable_flag_result = cursor.fetchone()
        
        if fetch_enable_flag_result is not None:
            #Creating the source and target path using the table path, cycle id, and data date
            
            s3_data_copy_path = str(dataset_result['table_s3_path']).rstrip('/') + '/pt_data_dt=' + str(fetch_enable_flag_result['data_date']).replace("-","") + "/pt_cycle_id=" + str(fetch_enable_flag_result['cycle_id']) + "/"
            
            logger.info("S3 Path:"+s3_data_copy_path) 
            
            # copy data to hdfs using the path generated above, in case it does not copy log the process failure
            try:
                df_return = spark.read.parquet(s3_data_copy_path)
            except Exception as ex:
                status_message="Copying Failed while copying from s3 location {s3_data_copy_path}".format(s3_data_copy_path=s3_data_copy_path)
                logger.error(status_message)
                raise Exception(status_message)
            
            return df_return
        
        #msck repair of target table
        string_query = "msck repair table {target_tablename}".format(target_tablename=target_tablename)
        spark.sql(string_query)
        
        df_return = spark.sql("""select * from {target_tablename} where pt_cycle_id = (select max(pt_cycle_id) from {target_tablename})""".format(target_tablename=target_tablename))
        return df_return
        
    except Exception as ex:
        print(str(ex))
        raise ex
