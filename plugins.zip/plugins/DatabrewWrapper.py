import logging
import os
import re
import sys
import time
import traceback
from multiprocessing.pool import ThreadPool
from urllib import parse

import CommonConstants
# import utilities.common_utilities.code.CommonConstants as CommonConstants
from ConfigUtility import JsonConfigUtility
from CustomS3Utility import CustomS3Utility
from DataBrew_Utility import DataBrewUtility
from JsonFormatConverter import JsonFormatConverter
from ProfilerInputGenerator import ProfilerInputGenerator

# !/usr/bin/python
# -*- coding: utf-8 -*

# __author__ = "ZS Associates"

# """
# Doc_Type            : Data Brew Wrapper
# Tech Description    : Call Databrew API to create dataset and job if not created and run them.
# Pre_requisites      : N/A
# Inputs              : "run_id"  for which it needs to be run
# Outputs             : N/A
# Config_file         : CommonConstants file,environment_params.json
# Last modified by    : Abhishek kumar
# Last modified on    : 26th Aug 2021
# """


MODULE_NAME = "DatabrewWrapper"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(MODULE_NAME)


class DatabrewWrapper:

    def __init__(self, run_id):
        self.run_id = run_id

        self.s3_output_base_path = None

        self.profiler_db_name = None

        self.brewUtility = DataBrewUtility()

        self.mysql_conn = None

        self.module_path = os.path.dirname(os.path.abspath(__file__))

        self.failed_file_list = list()
        self.file_list = list()
        self.brew_response_dict = dict()

    def read_environement_config(self):
        """
        Description: Accept the location of environment config and
        read the config file to set the instance variables
        :param env_config_file_key: s3 path of environment config file.
        """
        response = dict()
        try:
            logger.info("Reading environment_params.json")

            config = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
            logger.info("Configs Read:" + str(config))

            logger.info(str(os.getcwd()))

            self.bucket_name = config.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "s3_bucket_name"])

            self.s3_output_base_path = config.get_configuration(
                [CommonConstants.ENVIRONMENT_PARAMS_KEY, "s3_profiler_process_base_path"])

            self.profiler_db_name = config.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
            self.file_schema_config_data = None

            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return response
        except Exception as exc:
            logger.error(traceback.format_exc())
            logger.error("Error Reading Env Configs: " + str(exc))
            response = {CommonConstants.STATUS_KEY: CommonConstants.STATUS_FAILED,
                        CommonConstants.ERROR_KEY: "Error reading environment configs" + str(exc)
                        }
            return response

    def poll_databrew_job(self, location_detail, brew_details):
        """
        Poll databrew job using brew api and mark the completed files as SUCCESS and write JSON to S3
        :param location_detail: dict containing file path for which databrew job has to be polled
        :param brew_details: details of databrew job for polling
        :return: status and poll response
        """
        response = dict()
        file_path = location_detail["file_path"]
        try:
            logger.info("Starting function to poll databrew job")

            logger.info("Brew Details" + str(brew_details))
            job_name = brew_details[1]
            run_id = brew_details[2]
            output_file_path = brew_details[3]

            poll_response = self.brewUtility.describe_job_run(jobname=job_name, runid=run_id)
            logger.info("Poll response:" + str(poll_response))
            if poll_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                while str('TooManyRequestsException').lower() in poll_response[CommonConstants.ERROR_KEY].lower():
                    time.sleep(5)
                    logger.warning("TooManyRequestsException found. calling describe_job_run again")
                    poll_response = self.brewUtility.describe_job_run(jobname=job_name, runid=run_id)

                    if poll_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_SUCCESS:
                        break

            if poll_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                raise Exception("Describe job run failed with error:" + poll_response[CommonConstants.ERROR_KEY])

            status = poll_response[CommonConstants.RESULT_KEY]["State"]

            if status in ["SUCCEEDED"]:
                data_brew_json_key = poll_response[CommonConstants.RESULT_KEY]["Outputs"][0]["Location"]["Key"]
                data_brew_json_location = CommonConstants.S3_PATH_PREFIX + self.bucket_name + '/' + data_brew_json_key
                jsonFormatConverter = JsonFormatConverter()
                json_response = jsonFormatConverter.main(input_source_data_path=file_path,
                                                         databrew_output_file_path=data_brew_json_location)
                if (json_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED):
                    error = "Error while converting JSON due to===>>" + str(json_response[CommonConstants.ERROR_KEY])
                    logger.error(error)
                    raise Exception(error)
                logger.info("JsonFormatterResponse" + str(json_response[CommonConstants.RESULT_KEY]))

                output_file_path_parsed = parse.urlparse(output_file_path)
                databrew_json_write = CustomS3Utility()._write_json_to_s3(bucket_name=output_file_path_parsed.netloc,
                                                                          key=output_file_path_parsed.path.lstrip('/'),
                                                                          data=json_response[
                                                                              CommonConstants.RESULT_KEY])
                if databrew_json_write[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                    raise Exception("Failed to write Final JSON to S3")

                obj = ProfilerInputGenerator(self.run_id)
                obj.update_status(file_path, output_file_path_parsed.path.lstrip('/'))
                self.brew_response_dict.pop(file_path)

            elif status in ["FAILED", "TIMEOUT"]:
                raise Exception("Databrew job failed for file:" + file_path)

            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            response[CommonConstants.RESULT_KEY] = poll_response
            return response

        except Exception as exc:

            self.failed_file_list.append(location_detail)
            self.brew_response_dict.pop(file_path)
            logger.error(str(exc))
            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            response[CommonConstants.ERROR_KEY] = str(exc)
            return response

    def call_databrew_utility(self, location_detail):
        """
        Description: Execute the databrew utility to get the relevant tags and write the output to s3
        with proper logging to RDS
        :param task: file details for which to run schema detection utility
        """
        response = dict()
        try:
            file_path = location_detail["file_path"]
            layer = location_detail["layer"]
            dataset_id = location_detail["dataset_id"]
            table_name = location_detail["table_name"]
            db_name = location_detail["db_name"]
            if layer == CommonConstants.APPLICATION_LAYER_TYPE:
                cycle_id = location_detail["cycle_id"]
                output_file_path = CommonConstants.S3_PATH_PREFIX + self.bucket_name + '/' + \
                                   "{profiler_base_path}/{layer}/dataset_id={dataset_id}/cycle_id={cycle_id}/{file_name}".format(
                                       profiler_base_path=self.s3_output_base_path,
                                       cycle_id=cycle_id,
                                       dataset_id=dataset_id,
                                       layer=layer,
                                       file_name=CommonConstants.DATABREW_FILE_NAME
                                   )
            else:
                batch_id = location_detail["batch_id"]
                output_file_path = CommonConstants.S3_PATH_PREFIX + self.bucket_name + '/' + \
                                   "{profiler_base_path}/{layer}/dataset_id={dataset_id}/batch_id={batch_id}/{file_name}".format(
                                       profiler_base_path=self.s3_output_base_path,
                                       batch_id=batch_id,
                                       dataset_id=dataset_id,
                                       layer=layer,
                                       file_name=CommonConstants.DATABREW_FILE_NAME
                                   )
            logger.info("Table name:" + table_name)
            logger.info("db name:" + db_name)
            logger.info("File Path:" + str(file_path))
            logger.info("layer:" + str(layer))
            logger.info("dataset_id:" + str(dataset_id))

            file_type = CommonConstants.PARQUET

            dataset_name = "{db_name}-{table_name}".format(db_name=re.sub('[^a-zA-Z0-9 \n.]', '', db_name),
                                                           table_name=re.sub('[^a-zA-Z0-9 \n.]', '', table_name))

            job_name = "{db_name}-{table_name}-job".format(db_name=re.sub('[^a-zA-Z0-9 \n.]', '', db_name),
                                                           table_name=re.sub('[^a-zA-Z0-9 \n.]', '', table_name))

            logger.info("output_file_path==>>" + output_file_path)

            file_path_parsed = parse.urlparse(file_path)
            output_file_path_parsed = parse.urlparse(output_file_path)

            brew_response = self.brewUtility.master_dataset_job(dataset_name=dataset_name,
                                                                job_name=job_name,
                                                                input_location=file_path_parsed.path.lstrip('/'),
                                                                output_location=output_file_path_parsed.path.lstrip(
                                                                    '/').replace(CommonConstants.DATABREW_FILE_NAME,
                                                                                 ''),
                                                                file_type=file_type
                                                                )

            if (brew_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED):
                raise Exception(brew_response[CommonConstants.ERROR_KEY])

            brew_run_id = brew_response[CommonConstants.RESULT_KEY]

            brew_details = [dataset_name, job_name, brew_run_id, output_file_path]
            logger.info("Brew Details:" + str(brew_details))
            self.brew_response_dict[file_path] = brew_details

            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return response

        except Exception as exc:
            logger.error(traceback.format_exc())
            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            response[CommonConstants.ERROR_KEY] = str(exc)
            response["input"] = location_detail

            return response

    def main(self, location_list):
        """
        Description: Execute the relevant functions one after the other.
        """
        response = dict()
        try:
            logger.info("Starting Main Function of SchemaDetectionWrapper")

            environment_response = self.read_environement_config()

            if environment_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                raise Exception(environment_response[CommonConstants.ERROR_KEY])

            p = ThreadPool(8)

            brew_response_status_list = p.map(self.call_databrew_utility, location_list)

            failed_list = []
            for status in brew_response_status_list:
                if status[CommonConstants.STATUS_KEY] in CommonConstants.STATUS_FAILED:
                    failed_details = status["input"]
                    failed_list.append(failed_details)
            if len(failed_list) == len(location_list):
                raise Exception("Brew Job Creation failed for all files.")
            logger.info("databrew job creation failed for following s3 paths and their error\n" + str(failed_list))
            logger.info("continuing polling the jobs which are running")

            while len(self.brew_response_dict):
                logger.info("Brew Response Dict:" + str(self.brew_response_dict))
                for location in location_list:
                    if location[CommonConstants.FILE_PATH_COLUMN] in self.brew_response_dict.keys():
                        self.poll_databrew_job(location,
                                               self.brew_response_dict[location[CommonConstants.FILE_PATH_COLUMN]])
                        time.sleep(5)

            if len(self.failed_file_list) != 0:
                if len(location_list) == len(self.failed_file_list):
                    raise Exception("job failed for all datasets")
                logger.error("databrew job run failed for following datasets \n" + str(self.failed_file_list))
                status = CommonConstants.STATUS_PARTIAL_SUCCESS
            else:
                status = CommonConstants.STATUS_SUCCESS
            response[CommonConstants.STATUS_KEY] = status

            logger.debug(str(response))

            return
        except Exception as exc:
            logger.error(traceback.format_exc())
            obj = ProfilerInputGenerator(self.run_id)
            for location in location_list:
                file_path = location["file_path"]
                status = CommonConstants.STATUS_FAILED
                obj.update_profiler_smry(file_path, status)
            raise exc