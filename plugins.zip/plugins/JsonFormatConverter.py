#!/usr/bin/python
# -*- coding: utf-8 -*

# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of this source code package.

__author__ = "ZS Associates"

import json
import logging
# Library and external modules declaration
import os
import sys
import traceback

# import ProfilerConstants as CommonConstants
import CommonConstants
import boto3
from ConfigUtility import JsonConfigUtility
from CustomS3Utility import CustomS3Utility

sys.path.insert(0, os.getcwd())

# all module level constants are defined here
MODULE_NAME = "JsonFormatConverter"
PROCESS_NAME = "Convert the AWS Databrew JSON output to JSON format of CC Data Profiler"

# Set logging level
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(MODULE_NAME)


# ####################################################Module Information################################################
#  Module Name         :   JsonFormatConverter
#  Purpose             :   This module will Convert the JSON output of AWS Databrew to JSON format of CC Data Profiler.
#  Input Parameters    :   input_source_data_path: File location of source data
#                          databrew_output_file_path: Profiler output file path of databrew
#                          delimiter: Field delimiter in source data
#                          header: Presence of header in source data
#                          delimiter_accuracy: The accuracy level of delimiter with which the delimiter was found using
#                                     delimiter detection utility
#
#  Output Value        :   {
#                           "status" : "SUCCESS",
#                           "result": cc_profiler_output_file_path
#                           }
#  Pre-requisites      :
#  Last changed on     :   26 March 2021
#  Last changed by     :   Sukhwinder Singh
#  Reason for change   :
# ######################################################################################################################

class JsonFormatConverter(object):
    def __init__(self):
        """
        Purpose: Convert the AWS Databrew JSON output to JSON format of CC Data Profiler
        """
        self.s3 = boto3.resource("s3")
        self.configuration = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
        self.audit_db = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
        self.cc_format = JsonConfigUtility(CommonConstants.JSON_CONVERTER_LOOKUP_FILE)

    def json_format_converter(self, input_source_data_path, databrew_json_data):
        """

        :param input_source_data_path: File location of source data
        :param databrew_json_data: DATABREW JSON DATA
        :return: Will return the updated json format according to the provided lookup file
        """
        response = dict()
        result = dict()
        try:
            # Checking if the source data path is a file or a folder
            file_name = None
            file_type = None
            for format in CommonConstants.CC_FILE_FORMATS:
                if format in input_source_data_path.rsplit(".", 1):
                    file_type = input_source_data_path.rsplit(".", 1)[1]
                    file_name = input_source_data_path.rsplit("/", 1)[1]

            # Checking the file type if the path is a folder
            if file_type is None:
                file_type_list = []
                file_list = CustomS3Utility()._s3_list_files(input_source_data_path)

                if file_list[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_SUCCESS:
                    file_names = file_list[CommonConstants.RESULT_KEY]
                    logger.info("file_names for path {input_source_data_path} are {file_names}".format(
                        input_source_data_path=input_source_data_path,
                        file_names=str(file_names)
                    ))
                else:
                    return file_list
                if len(file_names) != 0:
                    for file in file_names:
                        if str(file).endswith("_SUCCESS"):
                            continue
                        file_name = input_source_data_path.strip("/").rsplit("/", 1)[1]
                        file_type_list.append(file.rsplit(".", 1)[1])
                else:
                    exception = "No files are present in the provided folder."
                    response[CommonConstants.ERROR_KEY] = exception
                    response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
                    return response

                if len(set(file_type_list)) == 1 and file_type_list[0] in CommonConstants.CC_FILE_FORMATS:
                    file_type = file_type_list[0]
                else:
                    exception = "Cannot process the files as file type is invalid or multiple file types have been" \
                                " provided in the folder."
                    response[CommonConstants.ERROR_KEY] = exception
                    response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
                    return response

            col_schema_list = list()
            if file_name is None or file_type is None:
                exception = "Cannot process the 'None' path. Please provide the valid input data path"
                response[CommonConstants.ERROR_KEY] = exception
                response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
                return response
            result[CommonConstants.DATABREW_SOURCE_FILENAME_KEY] = file_name
            result[CommonConstants.DATABREW_SOURCE_FILE_LOC_KEY] = input_source_data_path
            result[CommonConstants.DATABREW_SOURCE_FILE_TYPE_KEY] = file_type
            result[CommonConstants.DATABREW_COL_COUNT_KEY] = len(
                databrew_json_data[CommonConstants.DATABREW_COLUMN_KEY])
            databrew_common_keys = self.cc_format.get_configuration([CommonConstants.CC_FORMAT_KEY,
                                                                     CommonConstants.DATABREW_TO_CC_KEYS])
            for cc_key, databrew_key in databrew_common_keys.items():
                result[cc_key] = databrew_json_data[databrew_key]

            databrew_common_keys = self.cc_format.get_configuration([CommonConstants.CC_FORMAT_KEY,
                                                                     CommonConstants.DATABREW_COMMON_KEYS])

            for key in databrew_common_keys:
                result[key] = databrew_json_data[key]
            databrew_col_data = databrew_json_data[CommonConstants.DATABREW_COLUMN_KEY]

            sequence = 0
            logger.info(
                "databrew_col_data====>>>>>{databrew_col_data}".format(databrew_col_data=str(databrew_col_data)))
            logger.info("cc_lookup_json===>>>{lookup_json}".format(
                lookup_json=self.cc_format.get_configuration([CommonConstants.CC_FORMAT_KEY])
            ))
            for col_data in databrew_col_data:
                schema = dict()
                stats = dict()
                logger.info("col_data===>>{col_data}".format(
                    col_data=str(col_data)
                ))
                logger.info("col_type==>>{col_type}".format(
                    col_type=str(col_data[CommonConstants.DATABREW_TYPE_KEY].lower())
                ))
                cc_format_schema_json = self.cc_format.get_configuration([CommonConstants.CC_FORMAT_KEY,
                                                                          col_data[
                                                                              CommonConstants.DATABREW_TYPE_KEY].lower()])
                for cc_key, databrew_key in cc_format_schema_json.items():
                    if cc_key == CommonConstants.CC_SCHEMA_KEY:
                        for cc_key1, databrew_key1 in cc_format_schema_json[cc_key].items():
                            if cc_key1 == CommonConstants.CC_STATS_KEY:
                                for cc_key2, databrew_key2 in cc_format_schema_json[cc_key][cc_key1].items():
                                    if cc_key2 == CommonConstants.DATABREW_EXTRA_STATS_FUNCTIONS:
                                        for databrew_key3 in databrew_key2:
                                            stats[databrew_key3] = col_data[databrew_key3]
                                    else:
                                        stats[cc_key2] = col_data[databrew_key2]
                            elif cc_key1 == CommonConstants.CC_COLUMN_SEQUENCE_KEY and \
                                    databrew_key1 == CommonConstants.CC_ITERATE_LOOP_KEY:
                                sequence += 1
                                schema[cc_key1] = sequence
                            else:
                                schema[cc_key1] = col_data[databrew_key1]
                    else:
                        schema[cc_key] = col_data[databrew_key]
                schema[CommonConstants.CC_STATS_KEY] = stats
                col_schema_list.append(schema)
            result[CommonConstants.CC_SCHEMA_KEY] = col_schema_list
            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            response[CommonConstants.RESULT_KEY] = result
            return response

        except Exception as e:
            error = "Failed while processing the Databrew's output JSON data. ERROR is: {error}".format(
                error=str(e) + '\n' + str(traceback.format_exc()))
            logger.error(error)
            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            response[CommonConstants.RESULT_KEY] = "Error"
            response[CommonConstants.ERROR_KEY] = error
            return response

    def main(self, input_source_data_path, databrew_output_file_path):
        """

        :param input_source_data_path: File location of source data
        :param databrew_output_file_path: Profiler output file path of databrew
        :return: Will return the updated json format according to the provided lookup file
        """
        response = dict()
        try:
            bucket_name = databrew_output_file_path.split("//")[1].split("/", maxsplit=1)[0]
            s3_file_path = databrew_output_file_path.split("//")[1].split("/", maxsplit=1)[1]
            logger.info("The Output file path of Databrew in bucket '{bucket_name}' is '{s3_file_path}'".format(
                bucket_name=bucket_name,
                s3_file_path=s3_file_path))
            databrew_json_result = CustomS3Utility()._read_json_in_s3(bucket_name=bucket_name, key=s3_file_path)
            if databrew_json_result[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_SUCCESS:
                databrew_json_data = databrew_json_result[CommonConstants.RESULT_KEY]
            else:
                return databrew_json_result
            cc_profiler_json_result = self.json_format_converter(input_source_data_path=input_source_data_path,
                                                                 databrew_json_data=databrew_json_data)

            if cc_profiler_json_result[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_SUCCESS:
                cc_profiler_json_data = cc_profiler_json_result[CommonConstants.RESULT_KEY]
            else:
                return cc_profiler_json_result
            logger.info("The CC Data Profiler output is : {0}".format(json.dumps(cc_profiler_json_data)))
            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            response[CommonConstants.RESULT_KEY] = cc_profiler_json_data
            return response

        except Exception as e:
            error = "Failed to get the JSON format of CC Data Profiler from the output file '{file_name}' of Databrew. " \
                    "ERROR is: {error}".format(file_name=databrew_output_file_path,
                                               error=str(e) + '\n' + str(traceback.format_exc()))
            logger.error(error)
            response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            response[CommonConstants.RESULT_KEY] = "Error"
            response[CommonConstants.ERROR_KEY] = error
            response[CommonConstants.FILEPATH_KEY] = databrew_output_file_path
            return response
