import re
class PatternValidator(object):
    def len_check(self, source, pattern):
        try:
            return len(source) == len(pattern)
        except Exception as e:
            print("Exception occured in length check")
    def patter_validator(self, source, pattern):
        print (source+ "---" , pattern)
        if source.startswith("FACT"):
            reg = pattern.replace("N", "[0-9]")
            pattern = re.compile(reg)
            if pattern.search(source):
                return True
        elif "Gilead_Pharmacy_Claims_" in pattern and "Gilead_Pharmacy_Claims_" in source:
            return True
        elif "Gilead_Enrollment_" in pattern and "Gilead_Enrollment_" in source:
            return True
        elif source.endswith("csv") and "YYYY-MM-DD" in pattern:
            regex=pattern.replace("YYYY-MM-DD","([0-9]{4})-(1[0-2]|0[1-9])-(0[1-9]|[1-2][0-9]|3[0-1])")
            pattern=re.compile(regex)
            if pattern.match(source):
                return True
            return False
        elif "MMYYYY" in pattern:
            regex = re.compile(r"(1[0-2]|0[1-9])([0-9]{4})")
            if regex.search(source):
                start_name = pattern.split("MMYYYY")[0]
                if source.startswith(start_name):
                    return True
            return False
        elif "YYYYMM" in pattern:
            regex = re.compile(r"([0-9]{4})(1[0-2]|0[1-9])")
            if regex.search(source):
                start_name = pattern.split("YYYYMM")[0]
                if source.startswith(start_name):
                    return True
            return False
        elif "YYYYMMDD" in pattern:
            if self.len_check(source, pattern):
                date_pattern = pattern.replace("YYYYMMDD", "([0-9]{4})(1[0-2]|0[1-9])(3[01]|[12][0-9]|0[1-9])")
                if re.match(date_pattern, source):
                    return True
                else:
                    return False
        #for handling month in alphabets
        elif "DDMONYYYY" in pattern:
            if self.len_check(source, pattern):
                date_pattern = pattern.replace("DDMONYYYY", "(3[01]|[12][0-9]|0[1-9])([A-Z]{3})([0-9]{4})")
                if re.match(date_pattern, source):
                    return True
                else:
                    return False
        elif "YYYY_MM_DD_######" in pattern:
            regex = pattern.replace("YYYY_MM_DD_######","([0-9]{4})_(1[0-2]|0[1-9])_(3[01]|[12][0-9]|0[1-9])_([0-9]{6})" )
            pattern = re.compile(regex)
            if pattern.search(source):
                return True
            else:
                return False
        elif "YYYYQ#" in pattern:
            print("inside q# condition")
            regex = re.compile(r"([0-9]{4}Q[1-4]{1})")
            if regex.search(source):
                if "MC" in pattern and "MC" in source:
                    print("mc in source and pattern")
                    return True
                elif "ADAP" in pattern and "ADAP" in source:
                    print("ADAP in source and pattern")
                    return True
                else:
                    print("no mc in pattern")
                    if "MC" not in pattern and "ADAP" not in pattern and "MC" not in source and "ADAP" not in source:
                        print("mc,ADAP not in pattern and source")
                        return True
                    else:
                        return False
        elif "N_YYYYMM" in pattern:
            regex = pattern.replace("N_YYYYMM", "([0-9])_([0-9]{4})(1[0-2]|0[1-9])")
            pattern = re.compile(regex)
            if pattern.search(source):
                return True
            return False
        elif pattern.startswith("LRX.PROD"):
            print("yes")
            if pattern.startswith("LRX.PROD.XD28351.XRER.") and source.startswith("LRX.PROD.XD28351.XRER.") and len(
                    pattern) == len(source):
                print(source.find(".CLI210"))
                if source.find(".CLI210") != -1:
                    return True
                else:
                    return False
            elif pattern.startswith("LRX.PROD.XD26053.RSMF.") and source.startswith("LRX.PROD.XD26053.RSMF.") and len(
                    pattern) == len(source):
                if source.find(".CLI210") != -1:
                    return True
                else:
                    return False
            elif pattern.startswith("LRX.PROD.XD26051.SFMF.") and source.startswith("LRX.PROD.XD26051.SFMF.") and len(
                    pattern) == len(source):
                if source.find(".CLI210") != -1:
                    return True
                else:
                    return False
            elif pattern.startswith("LRX.PROD.XD26052.ADDO.") and source.startswith("LRX.PROD.XD26052.ADDO.") and len(
                    pattern) == len(source):
                if source.find(".CLI210") != -1:
                    return True
                else:
                    return False
            elif pattern.startswith("LRX.PROD.XD28401.CORE.") and source.startswith("LRX.PROD.XD28401.CORE.") and len(
                    pattern) == len(source):
                if source.find(".CLI210") != -1:
                    return True
                else:
                    return False
            else:
                return False
        elif pattern.startswith("MMC.DEVL.GIL.L"):
            if "RX" in pattern and "RX" in source:
                return True
            elif "PATCOMP" in pattern and "PATCOMP" in source:
                return True
            elif "PRDLK" in pattern and "PRDLK" in source:
                return True
            elif "PLNLK" in pattern and "PLNLK" in source:
                return True
            elif "COMPAT" in pattern and "COMPAT" in source:
                print("99999999999999999999999999This is COMPAT Loop99999999999999999999999999999999999999")
                print(str(source))
                print(str(pattern))
                print("99999999999999999999999999This is COMPAT Loop99999999999999999999999999999999999999")
                return True
            elif "MPDPAT" in pattern and "MPDPAT" in source:
                print("++++++++++++++++++++++++++++This is MPDPAT loop++++++++++++++++++++++++++++++++++++")
                print(str(source))
                print(str(pattern))
                print("++++++++++++++++++++++++++++This is MPDPAT loop++++++++++++++++++++++++++++++++++++")
                return True
            elif ".PAT." in pattern and ".PAT." in source:
                print("0000000000000000000000000000This is PAT loop000000000000000000000000000000000000")
                print(str(source))
                print(str(pattern))
                print("0000000000000000000000000000This is PAT loop000000000000000000000000000000000000")
                return True
            elif "REJLK" in pattern and "REJLK" in source:
                return True
            elif "PVDLK" in pattern and "PVDLK" in source:
                return True
            elif "GEO" in pattern and "GEO" in source:
                return True
            elif "RXACT" in pattern and "RXACT" in source:
                return True
            elif "MX" in pattern and "MX" in source:
                return True
            elif "DXLK" in pattern and "DXLK" in source:
                return True
            elif "PXLK" in pattern and "PXLK" in source:
                return True
            elif "PLSVC" in pattern and "PLSVC" in source:
                return True
            elif "FACTYP" in pattern and "FACTYP" in source:
                return True
            elif "DXACT" in pattern and "DXACT" in source:
                return True
            elif "MDFR" in pattern and "MDFR" in source:
                return True
            elif "MODLK" in pattern and "MODLK" in source:
                return True
            else:
                return False


        else:
            if source == pattern:
                return True
        return False