#!/usr/bin/python3.6
# -*- coding: utf-8 -*-
# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of this source code package.
__author__ = 'ZS Associates'

"""
Module Name     :   SqoopUtilityConstants.py
Doc Type        :   Utility Constants
Tech Description:   This file contains the constants for SqoopIngestor.py
"""

CURR_PATH = os.getcwd()

UTILITIES_PATH = os.path.abspath( os.path.join( CURR_PATH, "../../utilities/" ))
sys.path.insert(0, UTILITIES_PATH)


SQL_KEY = "sqlserver"
ORACLE_KEY = "oracle"
POSTGRESQL_KEY = "postgresql"
MYSQL_KEY = "mysql"
CSV = "csv"
PARQUET = "parquet"
S3 = "s3"
S3_FOLDER_NAME_TIMESTAMP_FORMAT = '%Y-%m-%d-%H-%M-%S'
PERMITTED_DB_TYPES = [SQL_KEY, ORACLE_KEY, POSTGRESQL_KEY, MYSQL_KEY]
PERMITTED_OUTPUT_FILE_TYPES = [CSV, PARQUET]
DEFAULT_CLUSTER_USERNAME = "hadoop"
CLUSTER_SSH_PORT = "22"
CLUSTER_KEY_PATH = "emr_key_path"
SECRET_MANAGER_SERVICE_NAME = "secretsmanager"
TEMP_S3_PATH = "s3://aws-a0036-use1-00-d-s3b-rwcb-chb-data01/onboarding/sqoop/tmp/"
CLUSTER_STATUS = ["STARTING", "BOOTSTRAPPING", "RUNNING"]
CLUSTER_STATUS_TERMINATE = ['TERMINATING', 'TERMINATED', 'TERMINATED_WITH_ERRORS']
CLUSTER_STATUS_WAITING = "WAITING"
HDFS_TEMP_PATH = "/home/sqoop"
HADOOP_DISTCP = "hadoop distcp -Dmapreduce.map.memory.mb=4096 "
HADOOP_LIST_FILE_COMMAND = "hadoop fs -ls /home/sqoop"
