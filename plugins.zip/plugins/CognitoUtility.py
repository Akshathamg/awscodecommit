#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'ZS Associates'
 
"""
Module Name         :   Cognito Utility
Purpose             :   Cognito utility module to validate cognito tokens
Pre_requisites      :   NA
Input Parameters    :   NA
Output              :   NA
Execution Steps     :   Route requests to appropriate methods and return results
Last changed on     :   14 June 2021
Last changed by     :   Harika Kanakam
Reason for change   :   NA
"""
 
import requests
from envs import env
from jose import JWTError, jwt
 
from fastapi import HTTPException
 

class CognitoUtil:
    """
        This is a class to create all the cognito operation methods
    """
    def __init__(self, user_pool_id, client_id):
        """
 
        :param user_pool_id: User pool Id
        :param client_id: Client Id
        """
        self.user_pool_region = user_pool_id.split("_")[0]
        self.user_pool_id = user_pool_id
        self.client_id = client_id
        self.pool_jwk = None
        self.user_pool_url = f"https://cognito-idp.{self.user_pool_region}.amazonaws.com/{self.user_pool_id}"
 
    def get_keys(self):
        if self.pool_jwk:
            return self.pool_jwk
 
        pool_jwk_env = env("COGNITO_JWKS", {}, var_type="dict")
        if pool_jwk_env:
            self.pool_jwk = pool_jwk_env
        else:
            self.pool_jwk = requests.get(
                f"{self.user_pool_url}/.well-known/jwks.json"
            ).json()
        return self.pool_jwk
 
    def get_key(self, kid):
        keys = self.get_keys().get("keys")
        key = list(filter(lambda x: x.get("kid") == kid, keys))
        return key[0]
 
    def verify_token(self, token, id_name, token_use, **kwargs):
        kid = jwt.get_unverified_header(token).get("kid")
        hmac_key = self.get_key(kid)
        status = False
        try:
            if token_use == 'access':
                verified = jwt.decode(
                    token,
                    hmac_key,
                    algorithms=["RS256"],
                    audience=self.client_id,
                    issuer=self.user_pool_url,
                    options={
                        "require_aud": token_use != "access",
                        "require_iss": True,
                        "require_exp": True,
                    },
                )
            else:
                access_token = kwargs.get('access_token', None)
                verified = jwt.decode(
                    token,
                    hmac_key,
                    algorithms=["RS256"],
                    audience=self.client_id,
                    issuer=self.user_pool_url,
                    access_token=access_token,
                    options={
                        "require_aud": True,
                        "require_iss": True,
                        "require_exp": True,
                    },
                )
            status = True
        except JWTError:
            status = False
            raise HTTPException(status_code=401, detail="Session expired. You are about to logout")
 
        token_use_verified = verified.get("token_use") == token_use
        if not token_use_verified:
            status = False
            raise HTTPException(status_code=401, detail="Session expired. You are about to logout")
 
        setattr(self, id_name, token)
        setattr(self, f"{token_use}_claims", verified)
        return status, verified
 
    def verify_tokens(self, id_token, access_token):
        id_status, id_validation = self.verify_token(id_token, "id_token", "id", access_token=access_token)
        access_status, access_validation = self.verify_token(access_token, "access_token", "access")
        if id_status and access_status:
            return True, id_validation
        else:
            return False