import sys
import boto3
import subprocess
from CommonUtils import CommonUtils
import CommonConstants as CommonConstants
sys.path.insert(1, CommonConstants.EMR_CODE_PATH + '/configs/job_executor')
 
import CreateHist

# DAG Variables
pt_cycle_id = '$$cycle_id'
data_dt = "$$data_dt"

# SPARK SETUP 
spark.sql("""set hive.exec.dynamic.partition.mode=nonstrict""")
spark.conf.set("spark.sql.crossJoin.enabled", "true")

########################## PROCESSING ########################################################

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_veeva_acnt""")
df.registerTempTable('stg_comm_ivnc_veeva_acnt')

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_veeva_call""")
df.registerTempTable('stg_comm_ivnc_veeva_call')

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_veeva_user""")
df.registerTempTable('stg_comm_ivnc_veeva_user')

df = spark.sql("""select * from comm_cur_ivnc_staging.d_comm_ivnc_align""")
df.registerTempTable('d_comm_ivnc_align')

df=spark.sql("""(
    select
        distinct ACNT.VID as VID, ACNT.CUST_TYPE as CUST_TYPE, ACNT.FULL_NM as FULL_NM, ACNT.REC_TYPE_ID, ACNT.IS_PRSN_ACNT as IS_PRSN_ACNT, ACNT.NPI as NPI,
        VCALL.CALL_ID as CALL_ID, VCALL.CALL_NM as CALL_NM,
        VUSER.REP_NM as REP_NM,
        VCALL.CALL_STATUS as CALL_STATUS, VCALL.PRNT_CALL as PRNT_CALL, VCALL.CALL_DT as CALL_DT, VCALL.CALL_DTTM as CALL_DTTM, VCALL.TRRTRY as TRRTRY, VCALL.CALL_TYPE as CALL_TYPE, VCALL.ATTNDEE as ATTNDEE, VCALL.ATTNDEE_TYPE as ATTNDEE_TYPE, VCALL.DTL_PROD as DTL_PROD, VCALL.USER_ID as USER_ID, VCALL.IS_PRNT_CALL as IS_PRNT_CALL, VCALL.DURATN as DURATN, VCALL.ADDR_LN_1 as ADDR_LN_1, VCALL.ADDR_LN_2 as ADDR_LN_2, VCALL.CITY as CITY, VCALL.ST as ST, VCALL.ZIP as ZIP, VCALL.CALL_CHNL as CALL_CHNL, VCALL.IOVNC_TYPE as IOVNC_TYPE, VCALL.IOVNC_PROD as IOVNC_PROD, VCALL.IOVNC_DURATN as IOVNC_DURATN, VCALL.IOVNC_DEPT as IOVNC_DEPT,
        ACNT.ATC_FLAG as ATC_FLAG,
        case
            when coalesce(ACNT.IS_PRSN_ACNT, '') = '' or upper(trim(ACNT.IS_PRSN_ACNT)) = 'NULL' then 'Other'
            when upper(trim(ACNT.IS_PRSN_ACNT)) = 'TRUE' then case when coalesce(PHCO.NM, '') = '' or upper(trim(PHCO.NM)) = 'NULL' then 'Other' else PHCO.NM end
            when upper(trim(ACNT.IS_PRSN_ACNT)) = 'FALSE' then case when coalesce(ACNT.FULL_NM, '') = '' or upper(trim(ACNT.FULL_NM)) = 'NULL' then 'Other' else ACNT.FULL_NM end
            else 'Other'
        end as PRNT_HCO,
        case
            when coalesce(ACNT.IS_PRSN_ACNT, '') = '' or upper(trim(ACNT.IS_PRSN_ACNT)) = 'NULL' then null
            when upper(trim(ACNT.IS_PRSN_ACNT)) = 'TRUE' then case when coalesce(PHCO.ID, '') = '' or upper(trim(PHCO.ID)) = 'NULL' then null else PHCO.ID end
            when upper(trim(ACNT.IS_PRSN_ACNT)) = 'FALSE' then case when coalesce(ACNT.VID, '') = '' or upper(trim(ACNT.VID)) = 'NULL' then null else ACNT.VID end
            else null
        end as PRNT_HCO_ID,
        ACNT.IOVNC_HCO_ACNT_TYPE as IOVNC_HCO_ACNT_TYPE, ACNT.IOVNC_AUTH_STATUS as IOVNC_AUTH_STATUS, ACNT.VEEVA_NWK_ID as VEEVA_NWK_ID,
        ACNT.FRST_NM as FRST_NM, ACNT.LAST_NM as LAST_NM
    from (
        select
            distinct case when coalesce(ID, '') = '' or upper(trim(ID)) = 'NULL' then null else ID end as VID,
            null as CUST_TYPE,
            case when coalesce(NM, '') = '' or upper(trim(NM)) = 'NULL' then null else NM end as FULL_NM,
            case when coalesce(LAST_NM, '') = '' or upper(trim(LAST_NM)) = 'NULL' then null else LAST_NM end as LAST_NM,
            case when coalesce(FRST_NM, '') = '' or upper(trim(FRST_NM)) = 'NULL' then null else FRST_NM end as FRST_NM,
            case when coalesce(REC_TYPE_ID, '') = '' or upper(trim(REC_TYPE_ID)) = 'NULL' then null else REC_TYPE_ID end as REC_TYPE_ID,
            case when coalesce(OWNR_ID, '') = '' or upper(trim(OWNR_ID)) = 'NULL' then null else OWNR_ID end as OWNR_ID,
            case when coalesce(IS_PRSN_ACNT, '') = '' or upper(trim(IS_PRSN_ACNT)) = 'NULL' then null else IS_PRSN_ACNT end as IS_PRSN_ACNT,
            case when coalesce(FRMT_NM, '') = '' or upper(trim(FRMT_NM)) = 'NULL' then null else FRMT_NM end as FRMT_NM,
            case when coalesce(NPI, '') = '' or upper(trim(NPI)) = 'NULL' then null else lpad(split(NPI, '-')[0], 10, '0') end as NPI,
            case
                when coalesce(IS_PRSN_ACNT, '') = '' or upper(trim(IS_PRSN_ACNT)) = 'NULL' then null
                when upper(trim(IS_PRSN_ACNT)) = 'TRUE' then 'N'
                when upper(trim(IS_PRSN_ACNT)) = 'FALSE' then 'Y'
                else null
            end as ATC_FLAG,
            case when coalesce(PRMRY_PRNT, '') = '' or upper(trim(PRMRY_PRNT)) = 'NULL' then null else PRMRY_PRNT end as PRMRY_PRNT,
            case when coalesce(IOVNC_HCO_ACNT_TYPE, '') = '' or upper(trim(IOVNC_HCO_ACNT_TYPE)) = 'NULL' then null else IOVNC_HCO_ACNT_TYPE end as IOVNC_HCO_ACNT_TYPE,
            case when coalesce(IOVNC_AUTH_STATUS, '') = '' or upper(trim(IOVNC_AUTH_STATUS)) = 'NULL' then null else IOVNC_AUTH_STATUS end as IOVNC_AUTH_STATUS,
            case when coalesce(VEEVA_NWK_ID, '') = '' or upper(trim(VEEVA_NWK_ID)) = 'NULL' then null else VEEVA_NWK_ID end as VEEVA_NWK_ID
        from stg_comm_ivnc_veeva_acnt
        where ( coalesce(ID, '') != '' and upper(trim(ID)) != 'NULL' )
    ) ACNT
    left outer join (
        select
            distinct case when coalesce(ID, '') = '' or upper(trim(ID)) = 'NULL' then null else ID end as CALL_ID,
            case when coalesce(OWNR_ID, '') = '' or upper(trim(OWNR_ID)) = 'NULL' then null else OWNR_ID end as OWNR_ID,
            case when coalesce(NM, '') = '' or upper(trim(NM)) = 'NULL' then null else NM end as CALL_NM,
            case when coalesce(REC_TYPE_ID, '') = '' or upper(trim(REC_TYPE_ID)) = 'NULL' then null else REC_TYPE_ID end as REC_TYPE_ID,
            case when coalesce(ACNT_ID, '') = '' or upper(trim(ACNT_ID)) = 'NULL' then null else ACNT_ID end as ACNT_ID,
            case when coalesce(STATUS, '') = '' or upper(trim(STATUS)) = 'NULL' then null else STATUS end as CALL_STATUS,
            case when coalesce(PRNT_ADDR, '') = '' or upper(trim(PRNT_ADDR)) = 'NULL' then null else PRNT_ADDR end as PRNT_ADDR,
            case when coalesce(CALL_DTTM, '') = '' or upper(trim(CALL_DTTM)) = 'NULL' then null else CALL_DTTM end as CALL_DTTM,
            case when coalesce(TRRTRY, '') = '' or upper(trim(TRRTRY)) = 'NULL' then null else TRRTRY end as TRRTRY,
            case when coalesce(CALL_TYPE, '') = '' or upper(trim(CALL_TYPE)) = 'NULL' then null else CALL_TYPE end as CALL_TYPE,
            case when coalesce(ATTNDEE, '') = '' or upper(trim(ATTNDEE)) = 'NULL' then null else ATTNDEE end as ATTNDEE,
            case when coalesce(ATTNDEE_TYPE, '') = '' or upper(trim(ATTNDEE_TYPE)) = 'NULL' then null else ATTNDEE_TYPE end as ATTNDEE_TYPE,
            case when coalesce(CALL_DT, '') = '' or upper(trim(CALL_DT)) = 'NULL' then null else CALL_DT end as CALL_DT,
            case when coalesce(DTL_PROD, '') = '' or upper(trim(DTL_PROD)) = 'NULL' then null else DTL_PROD end as DTL_PROD,
            case when coalesce(PRNT_CALL, '') = '' or upper(trim(PRNT_CALL)) = 'NULL' then null else PRNT_CALL end as PRNT_CALL,
            case when coalesce(USER_ID, '') = '' or upper(trim(USER_ID)) = 'NULL' then null else USER_ID end as USER_ID,
            case when coalesce(IS_PRNT_CALL, '') = '' or upper(trim(IS_PRNT_CALL)) = 'NULL' then null else IS_PRNT_CALL end as IS_PRNT_CALL,
            case when coalesce(IS_SAMPLE_CALL, '') = '' or upper(trim(IS_SAMPLE_CALL)) = 'NULL' then null else IS_SAMPLE_CALL end as IS_SAMPLE_CALL,
            case when coalesce(DURATN, '') = '' or upper(trim(DURATN)) = 'NULL' then null else DURATN end as DURATN,
            case when coalesce(ADDR_LN_1, '') = '' or upper(trim(ADDR_LN_1)) = 'NULL' then null else ADDR_LN_1 end as ADDR_LN_1,
            case when coalesce(ADDR_LN_2, '') = '' or upper(trim(ADDR_LN_2)) = 'NULL' then null else ADDR_LN_2 end as ADDR_LN_2,
            case when coalesce(CITY, '') = '' or upper(trim(CITY)) = 'NULL' then null else CITY end as CITY,
            case when coalesce(ST, '') = '' or upper(trim(ST)) = 'NULL' then null else ST end as ST,
            case when coalesce(ZIP, '') = '' or upper(trim(ZIP)) = 'NULL' then null else lpad(split(ZIP, '-')[0], 5, '0') end as ZIP,
            case when coalesce(CNTRY_CD, '') = '' or upper(trim(CNTRY_CD)) = 'NULL' then null else CNTRY_CD end as CNTRY_CD,
            case when coalesce(PRNT_ADDR_ID, '') = '' or upper(trim(PRNT_ADDR_ID)) = 'NULL' then null else PRNT_ADDR_ID end as PRNT_ADDR_ID,
            case when coalesce(CALL_CHNL, '') = '' or upper(trim(CALL_CHNL)) = 'NULL' then null else CALL_CHNL end as CALL_CHNL,
            case when coalesce(IOVNC_TYPE, '') = '' or upper(trim(IOVNC_TYPE)) = 'NULL' then null else IOVNC_TYPE end as IOVNC_TYPE,
            case when coalesce(IOVNC_PROD, '') = '' or upper(trim(IOVNC_PROD)) = 'NULL' then null else IOVNC_PROD end as IOVNC_PROD,
            case when coalesce(IOVNC_DURATN, '') = '' or upper(trim(IOVNC_DURATN)) = 'NULL' then null else IOVNC_DURATN end as IOVNC_DURATN,
            case when coalesce(IOVNC_DEPT, '') = '' or upper(trim(IOVNC_DEPT)) = 'NULL' then null else IOVNC_DEPT end as IOVNC_DEPT
        from stg_comm_ivnc_veeva_call
        where ( coalesce(ID, '') != '' and upper(trim(ID)) != 'NULL' )
    ) VCALL
    on ACNT.VID = VCALL.ACNT_ID
    left outer join (
        select ID as ID, case when coalesce(NM, '') = '' or upper(trim(NM)) = 'NULL' then null else NM end as NM
        from stg_comm_ivnc_veeva_acnt
        where ( coalesce(ID, '') != '' and upper(trim(ID)) != 'NULL' )
    ) PHCO
    on coalesce(ACNT.PRMRY_PRNT, 'x') = coalesce(PHCO.ID, 'xx')
    left outer join (
        select
            distinct case when coalesce(ID, '') = '' or upper(trim(ID)) = 'NULL' then null else ID end as USERID,
            case when coalesce(NM, '') = '' or upper(trim(NM)) = 'NULL' then null else NM end as REP_NM
        from stg_comm_ivnc_veeva_user
        where ( coalesce(ID, '') != '' and upper(trim(ID)) != 'NULL' )
    ) VUSER
    on VCALL.OWNR_ID = VUSER.USERID
    where VCALL.CALL_DT is not null
)""")
df.registerTempTable('f_comm_ivnc_call_activity')

spark.sql("""insert overwrite table comm_pro_ivnc_dw.f_comm_ivnc_call_activity PARTITION(pt_data_dt='$$data_dt',pt_cycle_id='$$cycle_id') select * from f_comm_ivnc_call_activity""")

#Sample data transformation is completed, now pusing the result to compute and publish layer

CommonUtils().copy_hdfs_to_s3("comm_pro_ivnc_dw.f_comm_ivnc_call_activity")