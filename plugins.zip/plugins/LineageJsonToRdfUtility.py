#!/usr/bin/python
# -*- coding: utf-8 -*-
# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of this source code package.
__author__ = 'ZS Associates'

######################################################Module Information################################################
#   Module Name         :   LineageJsonToRdfUtility
#   Purpose             :   Utility to convert lineage json file to RDF format.
#   Input Parameters    :   s3_input_file_path, s3_output_file_path, Lineage Rdf Configuration File 
#   Output              :   ttl file (RDF ttl file)
#   Execution Steps     :   Instantiate a graph object and add triples to this object based on rules mentioned in configuration file. Serialize the graph and save the triples to S3.  
#   Predecessor module  :   NA
#   Successor module    :   NA
#   Last changed on     :   27 August 2021
#   Last changed by     :   Apuroop
#   Reason for change   :   NA
########################################################################################################################

import os
import ast
import argparse
import json
import sys
import logging

import boto3
import hashlib
from rdflib import Graph, Literal, Namespace, URIRef

SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
project_path = os.sep.join(SCRIPTS_DIR.split(os.sep)[0:-3])
project_path = os.path.join(project_path, "configs")
sys.path.insert(1, project_path)
import CommonConstants

project_path = os.sep.join(SCRIPTS_DIR.split(os.sep)[0:-3])
# lineage_rdf_configuration_path = "configs/lineageRdfConfiguration.json"
lineage_rdf_configuration_path = "lineageRdfConfiguration.json"
# lineage_rdf_configuration_path = os.path.join(project_path, lineage_rdf_configuration_path)

project_path = os.sep.join(SCRIPTS_DIR.split(os.sep)[0:-3])
temp_directory_path = "tmp/"
temp_directory_path = os.path.join(project_path, temp_directory_path)

# logging
MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class LineageJsonToRdfUtility():
    def __init__(self):
        """ Initiate variable """

    def read_json(self, file_path):
        """
            Purpose   :   This function is used to read file and return json objects
            Input     :   Path of json file(string)
            Output    :   Json object(dict)
        """
        return_response = dict()
        try:
            with open(file_path) as conf:
                file_obj = json.load(conf)
            logger.info("read json file")
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return_response[CommonConstants.RESULT_KEY] = file_obj
            return return_response
        except Exception as ex:
            error_message = "An error has occured while reading the json file. Error message: " + str(ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response

    def create_hash(self, entity_str):
        """
            Purpose     :   This function is used to create hash id for a given string
            Input       :   Entity_str (string)
            Output      :   Key_data_str (string)
        """
        return_response = dict()
        try:
            key_data = hashlib.md5(str(entity_str).encode('UTF-8'))
            key_data_str = str(key_data.hexdigest())
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return_response[CommonConstants.RESULT_KEY] = key_data_str
            return return_response

        except Exception as ex:
            error_message = "An error has occured while creating hash value. Error message: " + str(ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response

    def get_entityname(self, data, config):
        """
            Purpose     :   This function is used to get entity label for graph
            Input       :   lineage data, config_file
            Output      :   triples
            
        """
        return_response = dict()
        try:
            subject_str = config['non_literal'][data["type"]]["identifier"]["identifier_prefix"]
            for i in config['non_literal'][data["type"]]["identifier"]["keyword"]:
                subject_str = subject_str + data[i]
            create_hash_response = self.create_hash(subject_str)
            if create_hash_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                return create_hash_response
            else:
                subject_hash = create_hash_response[CommonConstants.RESULT_KEY]
            s = URIRef(f"{self.dmp}{subject_hash}")
            p = URIRef(
                f"{config['predicate_value']['entityName'].replace('dmp:', self.dmp).replace('skos:', self.skos)}")
            obj_value = data[config['non_literal'][data["type"]]["entityName"]]
            o = Literal(obj_value)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return_response[CommonConstants.RESULT_KEY] = (s, p, o)
            return return_response
        except Exception as ex:
            error_message = "An error has occured while creating rdf triplets for entity name. Error message: " + str(
                ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response

    def get_type(self, data, config):
        """
            Purpose     :   This function is used to get subject type
            Input       :   lineage data, config_file
            Output      :   triples
        """
        return_response = dict()
        try:
            subject_str = config['non_literal'][data["type"]]["identifier"]["identifier_prefix"]
            for i in config['non_literal'][data["type"]]["identifier"]["keyword"]:
                subject_str = subject_str + data[i]
            create_hash_response = self.create_hash(subject_str)
            if create_hash_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                return create_hash_response
            else:
                subject_hash = create_hash_response[CommonConstants.RESULT_KEY]
            s = URIRef(f"{self.dmp}{subject_hash}")
            p = self.rdf.type
            type_value = config['non_literal'][data["type"]]["rdf_type"]
            o = URIRef(f"{type_value.replace('dmp:', self.dmp)}")
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return_response[CommonConstants.RESULT_KEY] = (s, p, o)
            return return_response
        except Exception as ex:
            error_message = "An error has occured while creating rdf triplets (in function: get_type). Error message: " + str(
                ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response

    def get_subject(self, subject_data, config):
        """
            Purpose     :   This function is used to get subject
            Input       :   lineage data, config_file
            Output      :   subject
        """
        return_response = dict()
        try:
            if subject_data["type"] in config["non_literal"].keys():
                subject_str = config["non_literal"][subject_data["type"]]["identifier"]["identifier_prefix"]
                for i in config["non_literal"][subject_data["type"]]["identifier"]["keyword"]:
                    subject_str = subject_str + subject_data[i]
                create_hash_response = self.create_hash(subject_str)
                if create_hash_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                    return create_hash_response
                else:
                    subject_hash = create_hash_response[CommonConstants.RESULT_KEY]
                subject = URIRef(f"{self.dmp}{subject_hash}")
                return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
                return_response[CommonConstants.RESULT_KEY] = subject
                return return_response

            else:
                error_message = "Mismatch in subject."
                return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
                return_response[CommonConstants.ERROR_KEY] = error_message
                return return_response

        except Exception as ex:
            error_message = "An error has occured while creating subject. Error message: " + str(ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response

    def get_object(self, object_data, config):
        """
            Purpose     :   This function is used to get object
            Input       :   lineage data, config_file
            Output      :   object
        """
        return_response = dict()
        try:
            if object_data["type"] in config["non_literal"].keys():
                object_str = config["non_literal"][object_data["type"]]["identifier"]["identifier_prefix"]
                for i in config["non_literal"][object_data["type"]]["identifier"]["keyword"]:
                    object_str = object_str + object_data[i]
                create_hash_response = self.create_hash(object_str)
                if create_hash_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                    return create_hash_response
                else:
                    object_hash = create_hash_response[CommonConstants.RESULT_KEY]
                s_object = URIRef(f"{self.dmp}{object_hash}")
                return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
                return_response[CommonConstants.RESULT_KEY] = s_object
                return return_response

            elif object_data["type"] in config["literal"].keys():
                object_value = object_data[config["literal"][object_data["type"]]["keyword"]]
                s_object = Literal(object_value)
                return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
                return_response[CommonConstants.RESULT_KEY] = s_object
                return return_response
            else:
                error_message = "Mismatch in object."
                return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
                return_response[CommonConstants.ERROR_KEY] = error_message
                return return_response

        except Exception as ex:
            error_message = "An error has occured while creating object. Error message: " + str(ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response

    def get_predicate(self, predicate_data, config):
        """
            Purpose     :   This function is used to get predicate
            Input       :   lineage data, config_file
            Output      :   predicate
        """
        return_response = dict()
        try:
            predicate = URIRef(
                f"{config['predicate_value'][predicate_data].replace('dmp:', self.dmp).replace('skos:', self.skos)}")
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return_response[CommonConstants.RESULT_KEY] = predicate
            return return_response

        except Exception as ex:
            error_message = "An error has occured while creating predicate. Error message: " + str(ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response

    def create_lineage(self, s3_input_file_path=None, s3_output_file_path=None):
        """
            Purpose     :   This function is used to convert desired lineage Json to RDF ttl files
            Input       :   lineage Json files from source
            Output      :   ttl file
        """
        return_response = dict()
        try:
            self.output_graph = Graph()

            self.skos = Namespace(CommonConstants.SKOS_URI)
            self.output_graph.bind('skos', self.skos)

            self.rdf = Namespace(CommonConstants.RDF_URI)
            self.output_graph.bind('rdf', self.rdf)

            self.dmp = Namespace(CommonConstants.DMP_BASE_URI)
            self.output_graph.bind('dmp', self.dmp)

            read_json_response = LineageJsonToRdfUtility.read_json(self, lineage_rdf_configuration_path)
            if read_json_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                return read_json_response
            else:
                config = read_json_response[CommonConstants.RESULT_KEY]

            if s3_input_file_path is None:
                error_message = "S3 input file path cannot be blank"
                return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
                return_response[CommonConstants.ERROR_KEY] = error_message
                return return_response

            if s3_output_file_path is None:
                error_message = "S3 output file path cannot be blank"
                return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
                return_response[CommonConstants.ERROR_KEY] = error_message
                return return_response

            s3_input_path_split = s3_input_file_path.split('/')
            s3_input_bucket_name = s3_input_path_split[2]
            s3_input_base_path = '/'.join(s3_input_path_split[3:])
            client = boto3.client("s3")
            lineage_data = client.get_object(Bucket=s3_input_bucket_name, Key=s3_input_base_path)
            lineage_data = lineage_data["Body"].read().decode('utf-8')
            lineage_data = ast.literal_eval(lineage_data)

            for lineage in lineage_data["lineage"]:
                if lineage["subject"]["type"] in config['non_literal'].keys():
                    get_type_response = self.get_type(lineage['subject'], config)
                    if get_type_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                        return get_type_response
                    else:
                        self.output_graph.add(get_type_response[CommonConstants.RESULT_KEY])

                    get_entityname_response = self.get_entityname(lineage['subject'], config)
                    if get_entityname_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                        return get_entityname_response
                    else:
                        self.output_graph.add(get_entityname_response[CommonConstants.RESULT_KEY])

                if lineage["object"]["type"] in config['non_literal'].keys():
                    get_type_response = self.get_type(lineage['object'], config)
                    if get_type_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                        return get_type_response
                    else:
                        self.output_graph.add(get_type_response[CommonConstants.RESULT_KEY])

                    get_entityname_response = self.get_entityname(lineage['object'], config)
                    if get_entityname_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                        return get_entityname_response
                    else:
                        self.output_graph.add(get_entityname_response[CommonConstants.RESULT_KEY])

                logger.info(lineage["subject"], lineage["predicate"], lineage["object"])
                get_subject_response = self.get_subject(lineage["subject"], config)
                get_predicate_response = self.get_predicate(lineage["predicate"], config)
                get_object_response = self.get_object(lineage["object"], config)

                if get_subject_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                    return get_subject_response

                elif get_predicate_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                    return get_predicate_response

                elif get_object_response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                    return get_object_response
                else:
                    subject = get_subject_response[CommonConstants.RESULT_KEY]
                    predicate = get_predicate_response[CommonConstants.RESULT_KEY]
                    s_object = get_object_response[CommonConstants.RESULT_KEY]

                if len(predicate) > 0 and len(subject) > 0:
                    self.output_graph.add((subject, predicate, s_object))

            s3_output_path_split = s3_output_file_path.split('/')
            s3_output_bucket_name = s3_output_path_split[2]
            s3_output_base_path = '/'.join(s3_output_path_split[3:])

            final_output = self.output_graph.serialize(format='turtle')  # .decode()
            self.resource = boto3.resource("s3")
            self.resource.Object(s3_output_bucket_name, s3_output_base_path).put(Body=final_output)

            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_SUCCESS
            return_response[CommonConstants.RESULT_KEY] = None
            return return_response

        except Exception as ex:
            error_message = "An error has occured while creating ttl file. Error message: " + str(ex)
            return_response[CommonConstants.STATUS_KEY] = CommonConstants.STATUS_FAILED
            return_response[CommonConstants.ERROR_KEY] = error_message
            return return_response


def main(s3_input_file_path, s3_output_file_path):
    x = LineageJsonToRdfUtility()
    response = x.create_lineage(s3_input_file_path=s3_input_file_path, s3_output_file_path=s3_output_file_path)
    print(response)


if __name__ == "__main__":
    my_parser = argparse.ArgumentParser()
    my_parser.add_argument('--s3_input_file_path', type=str, required=True)
    my_parser.add_argument('--s3_output_file_path', type=str, required=True)

    args = my_parser.parse_args()

    s3_input_file_path = args.s3_input_file_path
    s3_output_file_path = args.s3_output_file_path

    main(s3_input_file_path, s3_output_file_path)
