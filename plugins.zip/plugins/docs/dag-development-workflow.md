### Airflow DAGs

#### The Workflow

All DAG developmnent should happen within the AWS-Global_Commercial repository. The [publish-dag workflow](../.github/workflows/publish-dags.yml)
will push any modified DAGs to s3. The workflow differs between the dev environment and higher environments. 

* When iterating against `dev`, the workflow will **pick up any DAG changes made in a Pull Rquest (PR)** against the dev branch. In order to ingest new
  changes on the airflow instance, you must continuously push up commits.
 
* When introducing DAG changes to higher environments, DAG changes detected in a merge into an environment branch will trigger the workflow. 


#### Updatig DAGs on the EC2 Airflow Instance

The most up-to-date versions of our airflow DAGs will end up on the EC2 instance in one of 2 ways:

1. A CRON job on the airflow EC2 instance will refresh the `/usr/lib/airflow/dags` dir with the latest
   dags stored in s3 daily at **12 a.m. IST**. All files within the dags directory will be deleted and replaced
   with the dags found in s3.
1. When working on a DAG during the day you can pull the latest version of your DAG by copying it down from the s3
   onto the airflow instance via the aws cli after you've pushed a commit to your PR!
   
   ```
   aws s3 cp s3://northstar-gilead-us-west-2-s3-orchestration-<env>/dags/northstar/<your-dag-name> <local directory>
   ```
