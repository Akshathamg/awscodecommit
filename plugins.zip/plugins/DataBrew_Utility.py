#!/usr/bin/python
# -*- coding: utf-8 -*

# __author__ = "ZS Associates"

# ####################################################Module Information################################################
# """
# Doc_Type            : DataBrew Utility
# Tech Description    : This module has all the helper functions that can be used for DataBrew
# Pre_requisites      : N/A
# Inputs              : 
# Outputs             : 
# Config_file         : ProfilerConstants file, Environment Params file
# Last modified by    : Abhishek kumar
# Last modified on    : 24th Aug 2021
# """
# ####################################################Module Information################################################

import logging
import os
import traceback

import CommonConstants
import boto3
from ConfigUtility import JsonConfigUtility
from botocore.config import Config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

MODULE_NAME = "DataBrew Utility"


# The usage sting to be displayed to the user for the utility
# USAGE_STRING = """
# SYNOPSIS
#     python3 DataBrew_Utility
#
#     Where
#
# """


class DataBrewUtility:
    """
    Description: This Class is used to run the DataBrew Utility
    """

    def __init__(self):
        """
        Description: Initialization of variables to be used
        """
        configure = Config(
            retries={
                'max_attempts': 10,
                'mode': 'standard'
            }
        )
        self.module_path = os.path.dirname(os.path.abspath(__file__))
        config = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
        self.region = config.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "databrew_region"])
        self.client = boto3.client("databrew", self.region, config=configure)
        self.logger = logging.getLogger(MODULE_NAME)

        self.bucket_name = None
        self.role_arn = None
        self.tags = None
        self.region = None

    def read_environment_config(self):
        """
        Description: Accept the location of environment config and
        read the config file to set the instance variables
        """
        try:

            self.logger.info("Reading environment_params.json")
            config = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)

            self.logger.info("Configs Read:" + str(config))

            self.logger.info(str(os.getcwd()))

            self.bucket_name = config.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "s3_bucket_name"])
            self.role_arn = config.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "databrew_role_arn"])
            self.tags = config.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "databrew_tags"])


        except Exception as exc:
            self.logger.error(traceback.format_exc())
            response = {CommonConstants.STATUS_KEY: CommonConstants.STATUS_FAILED,
                        CommonConstants.ERROR_KEY: "Error reading environment configs" + str(exc)
                        }
            return response

    def describe_dataset(self, dataset_name):
        """
        this describes a dataset in databrew to check if that dataset exists.
        :param dataset_name: name of the dataset to check for existance
        :return: Boolean True if exists, False otherwise
        """
        try:
            response = self.client.describe_dataset(
                Name=dataset_name
            )
            if response:
                return True
        except self.client.exceptions.ResourceNotFoundException:
            return False
        except Exception as e:
            self.logger.error(traceback.print_exc())
            raise e

    def describe_job(self, job_name):
        """
        this describes a jobs in databrew to check if that job exists.
        :param job_name: name of the job
        :return: true if exists, false otherwise
        """
        try:
            response = self.client.describe_job(
                Name=job_name
            )
            if response:
                return True
        except self.client.exceptions.ResourceNotFoundException:
            return False
        except Exception as e:
            self.logger.error(traceback.print_exc())
            raise e

    def update_dataset(self, dataset_name, input_location, file_type):
        """
        update the input location and file type of existing dataset in databrew.
        :param dataset_name: name of the dataset
        :param input_location: input location to be updated
        :param file_type: tupe of
        :return:
        """
        try:
            self.logger.info("updating Dataset {dataset} to input location {input_location}".format(
                dataset=dataset_name,
                input_location=input_location
            ))
            if file_type.lower() not in ["parquet"]:
                raise Exception("Unsupported File Format")
            response = self.client.update_dataset(
                Name=dataset_name,
                Input={
                    'S3InputDefinition': {
                        'Bucket': self.bucket_name,
                        'Key': input_location
                    }
                }
            )
            if not response:
                raise Exception("failed to update dataset {dataset_name}".format(dataset_name=dataset_name))
        except Exception as e:
            self.logger.error(traceback.print_exc())
            raise e

    def create_data_set(self, dataset_name, input_location, file_type):
        """
        Purpose: This function is used to create_data_set and get output response
        :param dataset_name: The Name with which Dataset is going to be created
        :param input_location: The location of the input file which will be used to create Dataset
        :param file_type: The type or format of the file, e.g csv, parquet
        :return: Dictionary which includes output of each module
        """
        try:
            self.logger.info("Creating Dataset")
            if file_type.lower() not in ["parquet"]:
                raise Exception("Unsupported File Format")

            response = self.client.create_dataset(
                Name=dataset_name,
                Input={
                    'S3InputDefinition': {
                        'Bucket': self.bucket_name,
                        'Key': input_location
                    }
                },
                Tags=self.tags
            )
            return response['Name']
        except Exception as ex:
            error = "Failed to execute Create Dataset. ERROR: " + str(ex)
            self.logger.error(error)
            self.logger.error(traceback.format_exc())
            raise Exception(ex)

    def update_profile_job(self, job_name, output_location):
        """
        update a existing job output location
        :param job_name: name of job
        :param output_location: new output location
        :return: None
        """
        try:
            self.logger.info("updating profile job {job_name} to output location {output_location}".format(
                job_name=job_name,
                output_location=output_location
            ))
            response = self.client.update_profile_job(
                Name=job_name,
                OutputLocation={
                    'Bucket': self.bucket_name,
                    'Key': output_location
                }
            )
            if not response:
                raise Exception("failed to update job {job_name}".format(job_name=job_name))
        except Exception as e:
            self.logger.error(traceback.print_exc())
            raise e

    def create_profile_job(self, dataset_name, job_name, output_location):
        """
        Purpose: This function is used to create_data_set and get output response
        :param dataset_name: The Name with which Dataset is going to be created
        :param output_location: The location of the Output file which will be used to store output
        :param job_name: The Job name which will be running
        :return: Dictionary which includes output of each module
        """
        try:
            response = self.client.create_profile_job(
                DatasetName=dataset_name,
                Name=job_name,
                OutputLocation={
                    'Bucket': self.bucket_name,
                    'Key': output_location
                },
                RoleArn=self.role_arn,
                Tags=self.tags,
                JobSample={
                    'Mode': 'FULL_DATASET'
                }
            )
            return response['Name']
        except Exception as ex:
            error = "Failed to execute Create Profile Job. ERROR: " + str(ex)
            self.logger.error(error)
            self.logger.error(traceback.format_exc())
            raise Exception(ex)

    def run_job(self, job_name):
        """
        Purpose: This function is used to run the job and get output response
        :param job_name: The Job name which will be running
        :return: Dictionary which includes output of each module
        """
        try:
            response = self.client.start_job_run(
                Name=job_name
            )
            return response['RunId']
        except Exception as ex:
            error = "Failed to execute Run Profile Job. ERROR: " + str(ex)
            self.logger.error(error)
            self.logger.error(traceback.format_exc())
            raise Exception(ex)

    def master_dataset_job(self, dataset_name, job_name, input_location, output_location, file_type):
        response = dict()
        try:
            self.logger.info("Reading Environment Config File")
            self.read_environment_config()
            dataset_exists = self.describe_dataset(dataset_name)
            if not dataset_exists:
                self.create_data_set(dataset_name=dataset_name, input_location=input_location, file_type=file_type)
            else:
                self.update_dataset(dataset_name, input_location, file_type)
            job_exists = self.describe_job(job_name)
            if not job_exists:
                self.create_profile_job(dataset_name=dataset_name, job_name=job_name,
                                        output_location=output_location)
            run_job_response = self.run_job(job_name=job_name)
            response["status"] = CommonConstants.STATUS_SUCCESS
            response["result"] = run_job_response
            return response
        except Exception as ex:
            error = "Failed to execute master dataset job function ERROR: " + str(ex)
            self.logger.error(error)
            self.logger.error(traceback.format_exc())
            response["status"] = CommonConstants.STATUS_FAILED
            response["error"] = error
            return response

    def list_dataset(self):
        """
        Purpose: This function is used to list the dataset get output response
        :return: Dictionary which includes output
        """
        response = dict()
        try:
            response = self.client.list_datasets()
            response["status"] = CommonConstants.STATUS_SUCCESS
            return response
        except Exception as ex:
            error = "Failed to execute list dataset.ERROR: " + str(ex)
            self.logger.error(error)
            self.logger.error(traceback.format_exc())
            response["status"] = CommonConstants.STATUS_FAILED
            response["error"] = error
            return response

    def describe_job_run(self, jobname, runid):
        """
        to get details of a job.
        :param jobname: job name
        :param runid: particular run of a job
        :return: status and result
        """
        response = dict()
        try:
            brew_response = self.client.describe_job_run(
                Name=jobname,
                RunId=runid
            )
            response["status"] = CommonConstants.STATUS_SUCCESS
            response["result"] = brew_response
            return response

        except Exception as ex:
            error = "Failed to execute describe job run. ERROR: " + str(ex)
            self.logger.error(error)
            self.logger.error(traceback.format_exc())
            response["status"] = CommonConstants.STATUS_FAILED
            response["error"] = error
            return response
