import sys
import boto3
import subprocess
from CommonUtils import CommonUtils
import CommonConstants as CommonConstants
sys.path.insert(1, CommonConstants.EMR_CODE_PATH + '/configs/job_executor')
 
import CreateHist

# DAG Variables
pt_cycle_id = '$$cycle_id'
data_dt = "$$data_dt"

# SPARK SETUP 
spark.sql("""set hive.exec.dynamic.partition.mode=nonstrict""")
spark.conf.set("spark.sql.crossJoin.enabled", "true")

########################## PROCESSING ########################################################

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_mdm_hcp""")
df.registerTempTable('stg_comm_ivnc_mdm_hcp')

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_mdm_addr""")
df.registerTempTable('stg_comm_ivnc_mdm_addr')

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_mdm_prnt_hco""")
df.registerTempTable('stg_comm_ivnc_mdm_prnt_hco')

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_mdm_license""")
df.registerTempTable('stg_comm_ivnc_mdm_license')

df = spark.sql("""select * from comm_cur_ivnc_staging.stg_comm_ivnc_veeva_acnt""")
df.registerTempTable('stg_comm_ivnc_veeva_acnt')

df=spark.sql("""(
    select
        distinct HCP.VID as VID, HCP.FRST_NM as FRST_NM, HCP.LAST_NM as LAST_NM, HCP.MIDDL_NM as MIDDL_NM, HCP.HCP_STATE as HCP_STATE, HCP.REC_STATE as REC_STATE, HCP.EMAIL_1 as EMAIL_1, HCP.GNDR as GNDR, HCP.NPI_NUM as NPI_NUM, HCP.OPT_OUT as OPT_OUT, HCP.REC_DELTA_ID as REC_DELTA_ID, HCP.REC_MRGD_VID as REC_MRGD_VID, HCP.SPCLTY_1 as SPCLTY_1,
        ADDR.ADDR_LN_1 as ADDR_LN_1, ADDR.ADDR_LN_2 as ADDR_LN_2, ADDR.CITY as CITY, ADDR.STATE as STATE, ADDR.ZIP as ZIP, ADDR.CNTRY as CNTRY, ADDR.ADDR_STATUS as ADDR_STATUS, ADDR.IOVNC_PRMRY_ADDR as IOVNC_PRMRY_ADDR, ADDR.ADDR_VID as ADDR_VID,
        PHCO.HRCHY_TYPE as HRCHY_TYPE, PHCO.IOVNC_PRMRY_RLTNSHP as IOVNC_PRMRY_RLTNSHP, PHCO.PRNT_HCO_STATUS as PRNT_HCO_STATUS, PHCO.PRNT_HCO_VID as PRNT_HCO_VID, PHCO.RLTNSHP_TYPE as RLTNSHP_TYPE,
        LIC.ANTCPTD_EXPRY_DT as ANTCPTD_EXPRY_DT, LIC.BEST_ST_LICENSE as BEST_ST_LICENSE, LIC.BODY as BODY, LIC.EFF_DT as EFF_DT, LIC.EXPRTN_DT as EXPRTN_DT, LIC.GRACE_PRD as GRACE_PRD, LIC.LICENSE_DEGREE as LICENSE_DEGREE, LIC.LICENSE_ELGBTY as LICENSE_ELGBTY, LIC.LICENSE_NUM as LICENSE_NUM, LIC.LICENSE_STATUS as LICENSE_STATUS, LIC.LICENSE_BODY as LICENSE_BODY, LIC.RXA_ELGBLE as RXA_ELGBLE, LIC.TYPE as TYPE, LIC.TYPE_VAL as TYPE_VAL,
        V_ACNT.TRGT_LEVEL as TRGT_LEVEL, V_ACNT.TRGT as TRGT
    from (
        select
            distinct VID as VID, FRST_NM as FRST_NM, LAST_NM as LAST_NM, MIDDL_NM as MIDDL_NM, HCP_STATUS as HCP_STATE, REC_ST as REC_STATE, EMAIL_1 as EMAIL_1, GNDR as GNDR, NPI_NUM as NPI_NUM, OPT_OUT as OPT_OUT, REC_DELTA_ID as REC_DELTA_ID, REC_MRGD_VID as REC_MRGD_VID, SPCLTY_1 as SPCLTY_1
        from stg_comm_ivnc_mdm_hcp
        where upper(trim(REC_ST)) = 'VALID'
            and upper(trim(HCP_STATUS)) = 'A'
            and ( coalesce(VID, '') != '' and upper(trim(VID)) != 'NULL' )
    ) HCP
    left outer join (
        select
            distinct ADDR_LN_1 as ADDR_LN_1, ADDR_LN_2 as ADDR_LN_2, LCLTY as CITY, ADMN_AREA as STATE,
            case
                when coalesce(POST_CD, '') = '' or upper(trim(POST_CD)) = 'NULL' then null
                else lpad(split(POST_CD, '-')[0], 5, '0')
            end as ZIP,
            CNTRY as CNTRY, ADDR_STATUS as ADDR_STATUS, IOVNC_PRMRY_ADDR as IOVNC_PRMRY_ADDR, VID as ADDR_VID, ETTY_VID as ETTY_VID
        from stg_comm_ivnc_mdm_addr
        where upper(trim(ETTY_TYPE)) = 'HCP'
            and upper(trim(REC_ST)) = 'VALID'
            and upper(trim(ADDR_STATUS)) = 'A'
            and ( coalesce(ETTY_VID, '') != '' and upper(trim(ETTY_VID)) != 'NULL' )
    ) ADDR
    on HCP.VID = ADDR.ETTY_VID
    left outer join (
        select
            distinct HRCHY_TYPE as HRCHY_TYPE, IOVNC_PRMRY_RLTNSHP as IOVNC_PRMRY_RLTNSHP, PRNT_HCO_STATUS as PRNT_HCO_STATUS, PRNT_HCO_VID as PRNT_HCO_VID, RLTNSHP_TYPE as RLTNSHP_TYPE, ETTY_VID as ETTY_VID
        from stg_comm_ivnc_mdm_prnt_hco
        where upper(trim(ETTY_TYPE)) = 'HCP'
            and upper(trim(REC_ST)) = 'VALID'
            and upper(trim(PRNT_HCO_STATUS)) = 'A'
            and ( coalesce(ETTY_VID, '') != '' and upper(trim(ETTY_VID)) != 'NULL' )
    ) PHCO
    on HCP.VID = PHCO.ETTY_VID
    left outer join (
        select
            distinct ANTCPTD_EXPRY_DT as ANTCPTD_EXPRY_DT, BEST_ST_LICENSE as BEST_ST_LICENSE, BODY as BODY, EFF_DT as EFF_DT, EXPRTN_DT as EXPRTN_DT, GRACE_PRD as GRACE_PRD, LICENSE_DEGREE as LICENSE_DEGREE, LICENSE_ELGBTY as LICENSE_ELGBTY, LICENSE_NUM as LICENSE_NUM, LICENSE_STATUS as LICENSE_STATUS, LICENSE_BODY as LICENSE_BODY, RXA_ELGBLE as RXA_ELGBLE, TYPE as TYPE, TYPE_VAL as TYPE_VAL, ETTY_VID as ETTY_VID
        from stg_comm_ivnc_mdm_license
        where upper(trim(ETTY_TYPE)) = 'HCP'
            and upper(trim(REC_ST)) = 'VALID'
            and upper(trim(LICENSE_STATUS)) = 'A'
            and ( coalesce(ETTY_VID, '') != '' and upper(trim(ETTY_VID)) != 'NULL' )
    ) LIC
    on HCP.VID = LIC.ETTY_VID
    left outer join (
        select distinct TRGT_LEVEL as TRGT_LEVEL, TRGT as TRGT, NM as NM, VEEVA_NWK_ID
        from stg_comm_ivnc_veeva_acnt
        where REC_TYPE_ID = '0128c000002fZ04AAE'
            and ( coalesce(NM, '') != '' and upper(trim(NM)) != 'NULL' )
    ) V_ACNT
    on trim(HCP.VID) = trim(V_ACNT.VEEVA_NWK_ID)
)""")
df.registerTempTable('d_comm_ivnc_hcp')

spark.sql("""insert overwrite table comm_pro_ivnc_dw.d_comm_ivnc_hcp PARTITION(pt_data_dt='$$data_dt',pt_cycle_id='$$cycle_id') select * from d_comm_ivnc_hcp""")

#Sample data transformation is completed, now pusing the result to compute and publish layer

CommonUtils().copy_hdfs_to_s3("comm_pro_ivnc_dw.d_comm_ivnc_hcp")