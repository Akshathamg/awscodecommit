import os
import sys
import datetime
import re
import sys
from string import *
from MySQLConnectionManager import MySQLConnectionManager
import boto3
import CommonConstants
from ConfigUtility import JsonConfigUtility
import pyspark
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

def createCsv(spark, process_id, query=None):
    today = datetime.date.today() - datetime.timedelta(days=datetime.date.today().weekday())
    today = str(today).replace("-", "")
    print(today)
    s3 = boto3.resource('s3')
    s3_client = boto3.client('s3')
    configuration = JsonConfigUtility(
            CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)
    audit_db = configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
    qry_file_name_list = "select table_s3_path, staging_location, dataset_name, dataset_type, document_link, tags from ctl_dataset_master where dataset_id={dataset_id} ".format(dataset_id=process_id)
    file_name_list = MySQLConnectionManager().execute_query_mysql(qry_file_name_list)
    print(file_name_list)
    table_loc=file_name_list[0]['table_s3_path']
    stage_loc=file_name_list[0]['staging_location']
    dataset_name=file_name_list[0]['dataset_name']
    dataset_type=file_name_list[0]['dataset_type']
    document_link=file_name_list[0]['document_link']
    tgt_file_name=file_name_list[0]['tags']
    print (table_loc)
    print (stage_loc)
    print (dataset_name)
    print (dataset_type)
    print (document_link)
    print (tgt_file_name)
    target_location=document_link
    if query!=None:
        df=spark.sql(query)
    df.repartition(1).write.option("header",True).option("delimiter","|").csv(target_location+"test", mode="overwrite")
    #Splitting the S3 path by '/'
    bucketsplitter=target_location.split('/')
    #Extracting bucket name
    bucket_name=bucketsplitter[2]
    #Extracting key from path
    key_splitter=target_location.split('/',3)
    key=key_splitter[3]
    print(bucket_name)
    print(key)
    print("+++++++++")
    res = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=key+'test/', MaxKeys=2)
    #print(res)
    if 'Contents' in res:
        keys = res['Contents']
        print(keys)
        print('s3://' + bucket_name+ '/'+ res['Contents'][1]['Key'])
        for i in keys:
            print(i['Key'])
            if 'part' in i['Key']:
                src = 's3://' + bucket_name+ '/'+ i['Key']
                tgt = 's3://' + bucket_name+ '/'+ key + tgt_file_name + '_' + today + '.csv'
                print("+++++")
                print(src)
                print(tgt)
                cpy_command='aws s3 cp '+src+' '+tgt
                delete_src=src.rsplit('/',1)
                delete_command='aws s3 rm '+delete_src[0]+'/ --recursive'
                print(delete_src)
                os.system(cpy_command)
        os.system(delete_command)
