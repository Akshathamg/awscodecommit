#!/usr/bin/python
# -*- coding: utf-8 -*-
# This file is subject to the terms and conditions defined in file 'LICENSE.txt' which is part of this source code package.
__AUTHOR__ = 'ZS Associates'

# ####################################################Module Information################################################
#  Module Name         :   LineageNeptuneLoadWrapper
#  Purpose             :   Loads Ingestion Data to Neptune DB
#  Input Parameters    :   None
#  Output Value        :   returns the status SUCCESS or FAILURE
#  Pre-requisites      :
#  Last changed on     :   3rd September 2021
#  Last changed by     :   Ashish Unadkat
#  Reason for change   :
# ######################################################################################################################

import logging
import os
import traceback
from datetime import datetime
from urllib.parse import urlparse

import CommonConstants

from ConfigUtility import JsonConfigUtility
from CustomS3Utility import CustomS3Utility
from MySQLConnectionManager import MySQLConnectionManager
from TaxonomyLoadWrapper import TaxonomyLoadWrapper
from NeptuneArchiveUtility import NeptuneArchiveUtility
from NeptuneLineageLoadUtility import NeptuneLineageLoadUtility

MODULE_NAME = 'LineageNeptuneLoadWrapper'
logger = logging.getLogger(MODULE_NAME)


class LineageNeptuneLoadWrapper:

    def __init__(self):
        if os.path.exists(CommonConstants.AIRFLOW_CODE_PATH):
            self.configuration = JsonConfigUtility(CommonConstants.AIRFLOW_CODE_PATH + '/' +
                                                   CommonConstants.ENVIRONMENT_CONFIG_FILE)
        else:
            self.configuration = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)

    def main(self):
        """
        Query RDS and call lineage load utility.
        :return: Success/Failure
        """

        try:
            logger.info("Starting Neptune Load Utility")
            db_name = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
            s3_bucket_name = self.configuration.get_configuration(
                [CommonConstants.ENVIRONMENT_PARAMS_KEY, "s3_bucket_name"])
            s3_base_path = self.configuration.get_configuration(
                [CommonConstants.ENVIRONMENT_PARAMS_KEY, "s3_graph_base_path"])

            lineage_rdf_path = self.configuration.get_configuration(
                [CommonConstants.ENVIRONMENT_PARAMS_KEY, "lineage_rdf_path"])
            archive_rdf_path = self.configuration.get_configuration(
                [CommonConstants.ENVIRONMENT_PARAMS_KEY, "archive_rdf_path"])

            run_id = datetime.strftime(datetime.utcnow(), "%Y%m%d%H%M%S")

            # ARCHIVE_FLAG = False
            domain_archived_list = []

            records_to_load = self.get_records_to_load(db_name)

            for record in records_to_load:
                new_run_id = record['run_id']

                new_s3_location = record['s3_location']
                new_s3_location = "s3://" + os.path.join(s3_bucket_name, new_s3_location)

                entity_type = record['entity_type']
                entity_name = record['entity_name']
                process_name = record['process_name']

                new_json_key = urlparse(new_s3_location, allow_fragments=False).path.lstrip('/')
                logger.info(s3_bucket_name, new_json_key)

                new_lineage_json = CustomS3Utility()._read_json_in_s3(bucket_name=s3_bucket_name,
                                                                      key=new_json_key)[CommonConstants.RESULT_KEY]
                lineage_json_domain = new_lineage_json['domain']

                # if not ARCHIVE_FLAG:
                if lineage_json_domain not in domain_archived_list:
                    s3_archive_directory_path = "s3://" + os.path.join(s3_bucket_name, s3_base_path,
                                                                       archive_rdf_path).format(
                                                                           run_id=run_id,
                                                                           domain_name=lineage_json_domain,
                                                                           process='lineage')
                    named_graph = CommonConstants.NAMED_GRAPH_URI.replace("$$domainName$$", lineage_json_domain)
                    archive_response = NeptuneArchiveUtility().archive_graph_data(named_graph=named_graph,
                                                                                  s3_archive_directory_path=s3_archive_directory_path)
                    domain_archived_list.append(lineage_json_domain)
                    # ARCHIVE_FLAG = True

                last_successful_lineage = self.get_last_succeful_lineage(db=db_name,
                                                                         entity_name=entity_name,
                                                                         run_id=new_run_id)

                new_lineage_output_path = "s3://" + os.path.join(s3_bucket_name, s3_base_path, lineage_rdf_path,
                                                                 "new").format(
                                                                     run_id=run_id,
                                                                     process=entity_type,
                                                                     entity_name=entity_name)

                old_lineage_output_path = None
                old_s3_location = None
                delete_triple_file_path = None

                if last_successful_lineage:
                    old_run_id = last_successful_lineage['run_id']
                    old_s3_location = last_successful_lineage['s3_location']
                    old_s3_location = "s3://" + os.path.join(s3_bucket_name, old_s3_location)

                    old_lineage_output_path = "s3://" + os.path.join(s3_bucket_name, s3_base_path, lineage_rdf_path,
                                                                     "old").format(
                                                                         run_id=run_id,
                                                                         process=entity_type,
                                                                         entity_name=entity_name)

                if old_lineage_output_path:
                    delete_triple_file_path = os.path.join(old_lineage_output_path, "delete.ttl")

                neptuneLineageLoadUtilityObj = NeptuneLineageLoadUtility()
                response = neptuneLineageLoadUtilityObj.incremental_lineage_load(
                    named_graph=named_graph,
                    prev_lineage_json_file_path=old_s3_location,
                    current_lineage_json_file_path=new_s3_location,
                    prev_lineage_ttl_output_directory_path=old_lineage_output_path,
                    current_lineage_ttl_output_directory_path=new_lineage_output_path,
                    delete_triple_file_path=delete_triple_file_path
                )

                if response[CommonConstants.STATUS_KEY] == CommonConstants.STATUS_FAILED:
                    raise Exception(response[CommonConstants.ERROR_KEY])

                self.set_graph_load_status(db=db_name, run_id=new_run_id, entity_name=entity_name,
                                           graph_load_status='Y')

            #Add Taxonomy
            taxonomyObj = TaxonomyLoadWrapper()
            taxonomyObj.main(run_id=run_id)

        except Exception as exc:
            logger.error(traceback.format_exc())
            logger.error(exc)
            raise exc

    def get_records_to_load(self, db):
        """
        Get the maximum run_id for lineage which has graph_load set as N
        :param db: Database name for the table.
        :return: Query Result
        """
        try:
            record_query = \
                "Select * from {db}.{lineage_table_name} where run_id in (Select max(run_id) as max_run_id from {db}.{lineage_table_name}  where status = '{success_status}' and graph_load_complete = 'N' " \
                "group by entity_name) and graph_load_complete = 'N' order by run_id asc".format(
                    db=db,
                    lineage_table_name=CommonConstants.LINEAGE_TBL_NM,
                    success_status=CommonConstants.STATUS_SUCCEEDED
                )
            record_query_result = MySQLConnectionManager().execute_query_mysql(record_query)

            return record_query_result

        except Exception as exc:
            logger.error(exc)
            raise exc

    def get_last_succeful_lineage(self, db, entity_name, run_id):
        """
        Get the last successfult lineage run for the given entity name.
        :param db: database in which the table resides
        :param entity_name: name of the entity.
        :param run_id: Latest run id for the entity
        :return: Query Results
        """

        try:
            get_last_succesful_lineage_query = "Select * from {db}.{lineage_table_name} where entity_name = '{entity_name}' and " \
                                               "run_id != '{run_id}' and status = '{success_status}' and run_id < {run_id} order by run_id desc limit 1".format(
                db=db,
                lineage_table_name=CommonConstants.LINEAGE_TBL_NM,
                success_status=CommonConstants.STATUS_SUCCEEDED,
                entity_name=entity_name,
                run_id=run_id
            )
            get_last_succeful_record_result = MySQLConnectionManager().execute_query_mysql(
                get_last_succesful_lineage_query, True)

            return get_last_succeful_record_result

        except Exception as exc:
            logger.error(exc)
            raise exc

    def set_graph_load_status(self, db, run_id, entity_name, graph_load_status):
        """
        Set the graph load status of a particular lineage record in the log table
        :param db: database in which the table resides
        :param run_id: run_id for the entity
        :param entity_name: name of the entity.
        :param graph_load_status: The status which you would like to set the field to - Accepted Values are Y/N
        :return: None
        """
        try:
            graph_load_status_query = "Update {db}.{lineage_dtl_table} set graph_load_complete = '{graph_load_status}', graph_load_time = NOW() where run_id = '{run_id}' and entity_name = '{entity_name}'".format(
                db=db,
                lineage_dtl_table=CommonConstants.LINEAGE_TBL_NM,
                run_id=run_id,
                entity_name=entity_name,
                graph_load_status=graph_load_status
            )
            MySQLConnectionManager().execute_query_mysql(graph_load_status_query, True)
            return
        except Exception as exc:
            logger.error(exc)
            raise exc


if __name__ == "__main__":
    LineageNeptuneLoadWrapper().main()