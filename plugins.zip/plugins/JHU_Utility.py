import os

#os.system("pip3 install pandas")
os.system("pip3 install numpy==1.17.5")
os.system("pip3 install fsspec==2021.08.1")
os.system("pip3 install s3fs")
os.system("pip3 install requests")
os.system("pip3 install sodapy")

import sys
#import subprocess
#subprocess.check_call([sys.executable,'-m','pip3','install','numpy==1.15.4'])
#subprocess.check_call([sys.executable,'-m','pip','install','fsspec==2021.6.0'])
#subprocess.check_call([sys.executable,'-m','pip','install','s3fs'])

#os.system("pip3 install --upgrade numpy")
os.system("pip3 install --upgrade awscli")
import pandas as pd
import datetime
import re
import sys
import requests
from MySQLConnectionManager import MySQLConnectionManager
import boto3
import CommonConstants
from ConfigUtility import JsonConfigUtility
from sodapy import Socrata
import csv

class JHU_Utility:

    today = datetime.date.today()
    today = str(today).replace("-", "")
    print(today)

    def gitUtility(git_repo,database_name):
        if os.path.exists('/tmp/' + database_name + '_temp/'):
            print("Folder already exists")
            os.chdir("/tmp/")
            os.system("rm -Rf "+ database_name + "_temp")
            print("Folder deleted")
        os.system("mkdir /tmp/" + database_name + "_temp/")
        print("Cloning git")
        os.system("git clone --depth 1 "+git_repo+" /tmp/" + database_name + "_temp/")

    def gitRemoveUtility(database_name):
        os.chdir("/tmp/")
        os.system("rm -Rf " + database_name + "_temp")
        print("Git clean up")

    def pivotDown(input_dir, dir, file_name, column_name, file_format, today):
        #input_dir = '/tmp/JHU_temp/csse_covid_19_data/csse_covid_19_time_series/'
        data = pd.read_csv(input_dir+file_name+'.'+file_format)
        print(data)
		
        list_of_columns = list(data.columns)
        print(list_of_columns)

        r = re.compile("[^^\d+/\d+/\d{2}$]")
        print(r)

        newlist = list(filter(r.match, list_of_columns))
        print(newlist)
        count_of_columns = len(newlist)
        data_pivot = (data.set_index(newlist)
         .stack()
         .reset_index(name=column_name)
         .rename(columns={'level_'+str(count_of_columns):'Date'}))
        print(data_pivot)

        file_name = file_name + "_" + today + "." + file_format
        print(file_name)
        bucket_splitter = dir.split('/')
        bucket_name = bucket_splitter[2]
        key_splitter = dir.split('/',3)
        key = key_splitter[3]
        data_pivot.to_csv(file_name, index = False)
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file(file_name, bucket_name, key + file_name)
        print("File successfully uploaded to location:" +dir)

    def git_copy(input_dir, dir, file_name, file_format, today):
        #input_dir = '/tmp/Oxford_temp/public/data/vaccinations/'
        data = pd.read_csv(input_dir+file_name+'.'+file_format)
        print(data)
        
        file_name = file_name + "_" + today + "." + file_format
        print(file_name)
        bucket_splitter = dir.split('/')
        bucket_name = bucket_splitter[2]
        key_splitter = dir.split('/',3)
        key = key_splitter[3]
        data.to_csv(file_name, index = False)
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file(file_name, bucket_name, key + file_name)
        print("File successfully uploaded to location:" +dir)

    def trim(dir, file_name, file_format, today):
        input_dir = '/tmp/JHU_temp/csse_covid_19_data/csse_covid_19_time_series/'
        data = pd.read_csv(input_dir+file_name+'.'+file_format, skiprows = 5)
        file_name = file_name + "_" + today + "." + file_format
        print(file_name)
        bucket_splitter = dir.split('/')
        bucket_name = bucket_splitter[2]
        key_splitter = dir.split('/',3)
        key = key_splitter[3]
        data.to_csv(file_name, index = False)
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file(file_name, bucket_name, key + file_name)
        print("File successfully uploaded to location:" +dir)

    def url_copy(file_url, dir, file_name, file_format, today):
        data_file = requests.get(file_url)
        data = data_file.content
        
        file_name = file_name + "_" + today + "." + file_format
        print(file_name)
        csv_file = open(file_name,'wb')
        csv_file.write(data)
        csv_file.close()
        
        bucket_splitter = dir.split('/')
        bucket_name = bucket_splitter[2]
        key_splitter = dir.split('/',3)
        key = key_splitter[3]
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file(file_name, bucket_name, key + file_name)
        print("File successfully uploaded to location:" + dir)

    def export_copy(file_url, api_endpoint, dir, file_name, file_format,today):
        AppToken = 'XSJrxbAdQRWaNgWcz74LxeVo0'
        UPPER_LIMIT = 100000000
        client = Socrata(file_url,AppToken)
        data = client.get(api_endpoint,content_type = file_format, limit = UPPER_LIMIT)
		
        file_name = file_name + "_" + today + "." + file_format
        print(file_name)
        
        input_dir = '/dev/shm/'
        with open(input_dir + file_name,'w') as f:
            write = csv.writer(f)
            write.writerows(data)
        
        bucket_splitter = dir.split('/')
        bucket_name = bucket_splitter[2]
        key_splitter = dir.split('/',3)
        key = key_splitter[3]
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file(input_dir + file_name, bucket_name, key + file_name)
        print("File successfully uploaded to location:" + dir)
	
    configuration = JsonConfigUtility(
            CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)
    audit_db = configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
    process_id = sys.argv[1]
    query = "select process_id, dataset_id, source_platform, database_name, incremental_load_column_name, src_system, object_name, source_location, target_location, output_file_name, output_file_format from ctl_ext_dataset_master where active_flag='Y' and process_id={process_id} ".format(process_id = process_id)
    query_list = MySQLConnectionManager().execute_query_mysql(query)
    print(query_list)
    source_platform = query_list[0]['source_platform']
    
    if source_platform == 'github' :
        git_repo = query_list[0]['object_name']
        database_name = query_list[0]['database_name']
        gitUtility(git_repo,database_name)
        for i in range(len(query_list)):
            dataset_id = query_list[i]['dataset_id']
            print(query_list[i]['dataset_id'])
            source_location = query_list[i]['source_location']
            target_location = query_list[i]['target_location']
            output_file_name = query_list[i]['output_file_name']
            output_file_format = query_list[i]['output_file_format']
            column_name = query_list[i]['incremental_load_column_name']
  
            if database_name == 'JHU':
                pivotDown(source_location, target_location, output_file_name, column_name, output_file_format, today)
            else :
                git_copy(source_location, target_location, output_file_name, output_file_format, today)
				
        gitRemoveUtility(database_name)
    
    elif source_platform == 'healthdata.gov' or source_platform == 'data.cdc.gov' :
        database_name = query_list[0]['database_name']
        for i in range(len(query_list)):
            dataset_id = query_list[i]['dataset_id']
            print(query_list[i]['dataset_id'])
            source_location = query_list[i]['source_location']
            target_location = query_list[i]['target_location']
            output_file_name = query_list[i]['output_file_name']
            output_file_format = query_list[i]['output_file_format']
            object_name = query_list[i]['object_name']
            export_copy(source_platform, object_name, target_location, output_file_name, output_file_format, today)
		
    elif source_platform == 'sjppappprdn01.na.gilead.com' :
        for i in range(len(query_list)):
            dataset_id = query_list[i]['dataset_id']
            print(query_list[i]['dataset_id'])
            source_location = query_list[i]['source_location']
            target_location = query_list[i]['target_location']
            output_file_name = query_list[i]['output_file_name']
            output_file_format = query_list[i]['output_file_format']
            source_location = source_location.replace('sjppappprdn01.na.gilead.com','10.118.176.74').replace(' ','%20')
            url_copy(source_location,target_location,output_file_name,output_file_format,today)        
    else :
        database_name = query_list[0]['database_name']
        for i in range(len(query_list)):
            dataset_id = query_list[i]['dataset_id']
            print(query_list[i]['dataset_id'])
            source_location = query_list[i]['source_location']
            target_location = query_list[i]['target_location']
            output_file_name = query_list[i]['output_file_name']
            output_file_format = query_list[i]['output_file_format']
            url_copy(source_location,target_location,output_file_name,output_file_format,today)
