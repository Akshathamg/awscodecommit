import traceback
import boto3
import os
import sys
import datetime
from pyspark.sql.functions import from_unixtime, unix_timestamp,col,lit
from datetime import date
from dateutil.relativedelta import relativedelta
import re
from pyspark.sql.functions import from_utc_timestamp
import sys
from MySQLConnectionManager import MySQLConnectionManager
import boto3
import CommonConstants
from ConfigUtility import JsonConfigUtility
import pyspark
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
sc = SparkContext('local')
spark = SparkSession(sc)

#parquet read resolution
spark.conf.set("spark.sql.parquet.enableVectorizedReader","false")
spark.conf.set("spark.sql.parquet.writeLegacyFormat","true")

class CsvUtility:
    #Read command-line params, common-constants
    today = date.today()
    print("++++today+++++++",today)
    today = str(today).replace("-", "")
    print(today)
    s3 = boto3.resource('s3')
    s3_client = boto3.client('s3')
    configuration = JsonConfigUtility(CommonConstants.AIRFLOW_CODE_PATH + '/' + CommonConstants.ENVIRONMENT_CONFIG_FILE)
    audit_db = configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
    process_id = sys.argv[1]
    process_id1 = sys.argv[2]
    print(type(process_id),"++++++++++++++++++++++")
    process_id = int(process_id)
   
    # Read CTL_DATASET_MASTER
    qry_file_name_list = "select table_s3_path, staging_location, dataset_name, dataset_type, document_link, tags from ctl_dataset_master where dataset_id={dataset_id} ".format(dataset_id=process_id)
    file_name_list = MySQLConnectionManager().execute_query_mysql(qry_file_name_list)
    print(file_name_list)
    table_loc=file_name_list[0]['table_s3_path']
    stage_loc=file_name_list[0]['staging_location']
    dataset_name=file_name_list[0]['dataset_name']
    #Dataset_type: raw(Stage Entry) or processed(DW entry)
    dataset_type=file_name_list[0]['dataset_type']
    #loction to store exportable csv extract generated from parquet. 
    document_link=file_name_list[0]['document_link']
    #exportable csv extract filename
    tgt_file_name=file_name_list[0]['tags']
    print (table_loc)
    print (stage_loc)
    print (dataset_name)
    print (dataset_type)
    print (document_link)
    print (tgt_file_name)
    
    #stg_id to be used in QC, setting stg_id to first parameter received
    stg_id=process_id
    #If the dataset_type is processed, fetch the latest succedded log_cycle_id, pt_data_dt and cycle_status
    if dataset_type=='processed':
        #if dataset type is processed, set stg_id to 2nd parameter, Stage dataset Id necessarily
        stg_id=process_id1
        log_dtl="select cycle_id, data_date, cycle_status from log_cycle_dtl where process_id= ( select process_id from ctl_process_dependency_master where dataset_id={dataset_id} and table_type='Target') and cycle_id=(select max(cycle_id) from log_cycle_dtl where process_id=( select process_id from ctl_process_dependency_master where dataset_id={dataset_id} and table_type='Target') and cycle_status in ('SUCCEEDED')) ".format(dataset_id=process_id)
        log_dtl_list = MySQLConnectionManager().execute_query_mysql(log_dtl)
        cycle_id=log_dtl_list[0]['cycle_id']
        data_date=log_dtl_list[0]['data_date']
        status=log_dtl_list[0]['cycle_status']
        print (cycle_id)
        print (data_date)
        print(status)
    #If the dataset_type is raw, fetch the latest successful batch_id and file_id
    elif dataset_type=='raw':  
        log_dtl="select file_id, batch_id from log_file_smry where dataset_id={dataset_id} and batch_id=(select max(batch_id) from log_file_smry where dataset_id={dataset_id}) and file_id=(select max(file_id) from log_file_smry where dataset_id={dataset_id} ) and file_status='SUCCEEDED'".format(dataset_id=process_id)
        log_dtl_list = MySQLConnectionManager().execute_query_mysql(log_dtl)
        batch_id=log_dtl_list[0]['batch_id']
        file_id=log_dtl_list[0]['file_id']
        print (batch_id)
        print (file_id)
    
    #QC Check: Checks if more than 1 records are ingested. If 0 records are ingested, then script exits sucessfully with exit code 0
    try:
        qry_rec_count="select record_count from log_ext_dataset_master where object_name in (select object_name from ctl_ext_dataset_master where dataset_id={dataset_id}) and substr(cycle_id,1,8)= replace(convert(sysdate(),char(10)),'-','')".format(dataset_id=stg_id)
        rec_count_dtst=MySQLConnectionManager().execute_query_mysql(qry_rec_count)
        rec_count=rec_count_dtst[0]['record_count']
    except:
        print("Record count is 0 for dataset_id:",process_id," in ctl_ext_dataset_master, for today's ingestion. Exiting with success")
        traceback.print_exc()
        exit(0)

    #Get Y marked column-list from ctl_column_metadata to select the columns to be published from dataframe
    columns_dtl = "select column_name from ctl_column_metadata where dataset_id={dataset_id} and column_tag='Y'".format(dataset_id=process_id)
    columns_dtl_list = MySQLConnectionManager().execute_query_mysql(columns_dtl)
    column_name=columns_dtl_list[0]['column_name']
    list_of_columns = []
    for i in columns_dtl_list:
        print(i['column_name'])
        list_of_columns.append(i['column_name'])
    print(list_of_columns)
    
    #Finalize the path to read parquet into dataframe
    path=''
    if dataset_type=='processed':
        if table_loc[-1] != '/':
            path=table_loc+'/pt_data_dt='+str(data_date).replace('-','')+'/pt_cycle_id='+str(cycle_id)
        else:
            path=table_loc+'pt_data_dt='+str(data_date).replace('-','')+'/pt_cycle_id='+str(cycle_id)
    elif dataset_type=='raw':
        if stage_loc[-1] != '/':
            path=stage_loc+'/pt_batch_id='+str(batch_id)+'/pt_file_id='+str(file_id)
        else:
            path=stage_loc+'pt_batch_id='+str(batch_id)+'/pt_file_id='+str(file_id)

    print(path)
    #read parquet into dataframe
    df = spark.read.parquet(path)
    
    #Query to fetch curr_max_refresh_timestamp (data filter date) for previous succeeded run
    query_top2_cycleid="select object_name,record_count,curr_max_refresh_timestamp,status,cycle_id from log_ext_dataset_master where status='SUCCEDED' and object_name in (select object_name from ctl_ext_dataset_master where dataset_id={id}) order by cycle_id desc limit 2;".format(id=stg_id)
    RS_top2_cycleid=MySQLConnectionManager().execute_query_mysql(query_top2_cycleid)
    #Filter out Records using curr_max_refresh_timestamp (data filter date) for previous succeeded run
    if len(RS_top2_cycleid)==2:
        df=df.filter("REPLACE(SystemModstamp,'T',' ') > {dt}".format(dt=RS_top2_cycleid[1]['curr_max_refresh_timestamp'].replace("\"","'").replace("{'time': ","").replace("}","")))
    
    target_location=document_link
    #Select columns from dataframe based on the column-list
    if(list_of_columns!=None):
        df=df.select(list_of_columns)
    
    #Write dataframe to csv, into export location
    df.repartition(1).replace("null","").write.option("header",True).option("delimiter","|").option("quoteAll", True).option("multiline",True).option("escape","\"").csv(target_location+"test/", mode="overwrite")
        #Splitting the S3 path by '/'
    bucketsplitter=target_location.split('/')
        #Extracting bucket name
    bucket_name=bucketsplitter[2]
        #Extracting key from path
    key_splitter=target_location.split('/',3)
    key=key_splitter[3]
    print(bucket_name)
    print(key)
    print("+++++++++")
    res = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=key+'test/', MaxKeys=2)
    #print(res)
    #tgt_file_name = dataset_name
    if 'Contents' in res:
        keys = res['Contents']
        print(keys)
        print('s3://' + bucket_name+ '/'+ res['Contents'][1]['Key'])
        for i in keys:
            print(i['Key'])
            if 'part' in i['Key']:
                src = 's3://' + bucket_name+ '/'+ i['Key']
                tgt_ec2 = '/tmp/csv/'
                tgt = 's3://' + bucket_name+ '/'+ key + tgt_file_name + '_' + today + '.csv'
                print("+++++")
                print(src)
                print(tgt)
                cpy_command='aws s3 cp '+src+' '+tgt
                cpy_command_1='aws s3 cp '+tgt_ec2+' '+tgt
                delete_src=src.rsplit('/',1)
                delete_command='aws s3 rm '+delete_src[0]+'/ --recursive'
                print(delete_src)
                os.system(cpy_command)
                #print("hi robo")
        os.system(delete_command)
    
    #Code to publish the CSV extract from export location to 3vue-gilead-bucket    
    Bucket_name = bucket_name
    Key = key +  tgt_file_name + '_' + today + '.csv'
    client = boto3.client('s3')
    source_response = client.get_object(Bucket= bucket_name,
                                        Key=Key)
    print(source_response)    
    destination_aws_access_key_id = "AKIAU77SWW2BCWBZRH7N"
    destination_aws_secret_access_key = "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"    
    destination_client = boto3.client('s3', aws_access_key_id='AKIAU77SWW2BCWBZRH7N',aws_secret_access_key='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')
    DESTINATIONBUCKET = "3vue-gilead-bucket"
    Path  = "G360_EMEA/" + tgt_file_name +"/" + tgt_file_name + '_' + today + '.csv'
    
    #QC Check: To check if the file gets uploaded
    try:
        destination_client.upload_fileobj(source_response['Body'], DESTINATIONBUCKET, Path)  # "Folder_location_in_destination_bucket"
    except:
        print("Error occured while publishing dataset_id:",process_id,"to the client bucket")
        traceback.print_exc()
        exit(99)

    response = destination_client.get_bucket_location(
        Bucket=DESTINATIONBUCKET
    )
    print(response)
