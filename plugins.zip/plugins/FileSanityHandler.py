#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'ZS Associates'

# ####################################################Module Information################################################
#  Module Name         :   FileSanityHandler
#  Purpose             :   This module will perform the additional steps in input files before invoking FileDownloadHandler.py.
#  Input Parameters    :   data_source, subject_area
#  Output Value        :   returns the status SUCCESS or FAILURE
#  Pre-requisites      :
#  Last changed on     :   28th June 2021
#  Last changed by     :   Tarun Kumar, Shrey Vijayvargiya
#  Reason for change   :   Ability to ingest fixed width or files with carriage return
# ######################################################################################################################

# Library and external modules declaration
import os
import traceback
import sys
import json
from pyspark.sql.functions import regexp_replace, col, trim, monotonically_increasing_id
from pyspark.sql.types import StructType
from typing import List
import subprocess
import boto3
from urllib.parse import urlparse

# sys.path.insert(0, os.getcwd())
from MoveCopy import MoveCopy
from LogSetup import logger
from ExecutionContext import ExecutionContext
import CommonConstants as CommonConstants
from CommonUtils import CommonUtils
from FileCheckUtility import FileCheckUtility
from MySQLConnectionManager import MySQLConnectionManager
from PySparkUtility import PySparkUtility
from ConfigUtility import JsonConfigUtility
from ParquetUtility import ParquetUtility
from Pattern_Validator import PatternValidator
from Pattern_Validator import PatternValidator
from pyspark.sql.types import *
from pyspark import SparkContext
from ConfigUtility import JsonConfigUtility
from pyspark.sql.functions import col, substring

MODULE_NAME = "FileSanityHandler"
PROCESS_NAME = "File Sanity Handler"

USAGE_STRING = """
SYNOPSIS
    python FileSanityHandler.py <data_source> <subject_area>

    Where
        input parameters : data_source , subject_area

"""


class FileSanityHandler:
    # Default constructor
    def __init__(self, spark_context=None, parent_execution_context=None):
        if parent_execution_context is None:
            self.execution_context = ExecutionContext()
        else:
            self.execution_context = parent_execution_context
        self.execution_context.set_context({"module_name": MODULE_NAME})
        self.move_copy_object = MoveCopy()
        self.configuration = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
        self.audit_db = self.configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
        self.spark_context = spark_context

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    # ########################################### execute_command ######################################################
    # Purpose            :   Executing the File Sanity check
    # Input              :   data source, subject area
    # Output             :   NA
    # ##################################################################################################################

    def blank_file_check(self,dbutils,file_master_id,source_file_location,header_flg,delimeter,file_pattern,spark_context=None):
        try:
            case = 0
            blank_file_flag = "N"
            status_message = ""
            processed_file_list = []
            status_message = "Executing blank file check function of module FileSanityHandler"
            source_file_location_dbfs = "/dbfs" + str(source_file_location)
            adls_file_list = CommonUtils().list_files_in_blob_directory(blob_dir_path=source_file_location_dbfs,file_pattern=file_pattern)
            processed_list_query = "select file_name from (select file_name,a.dataset_id from log_file_smry a inner join ctl_dataset_master b on a.dataset_id=b.dataset_id where a.dataset_id={dataset_id} and a.file_status='SUCCEEDED' and b.static_file_pattern='N') c".format(dataset_id=file_master_id)
            processed_list = MySQLConnectionManager().execute_query_mysql(processed_list_query)
            new_adls_file_list = []
            for file in adls_file_list:
                new_adls_file_list.append(file.replace('/dbfs','',1))

            for file in processed_list:
                path = file['file_name']
                substring = "/" + str(path.split('/')[1])
                if substring == "/dbfs":
                    new_path = path.replace(substring, "", 1)
                    new_path = new_path.replace(" ", "")
                else:
                    new_path = path
                processed_file_list.append(new_path)

            unprocessed_file_list = list(set(new_adls_file_list)-set(processed_file_list))
            unprocessed_file_count = len(unprocessed_file_list)

            query_string = "select mandatory_flag from ctl_ext_dtst_master where dataset_id={dataset_id}".format(dataset_id=file_master_id)
            mandatory_flag_output = MySQLConnectionManager().execute_query_mysql(query_string)
            mandatory_flag = "N"
            for flag in mandatory_flag_output:
                mandatory_flag = flag['mandatory_flag']
            
            if mandatory_flag is None: 
                mandatory_flag='N'

            if mandatory_flag.lower() == "y":
                if unprocessed_file_count == 0:
                    case = 1 #case 1 is when we want to proceed to ingestion
                else:
                    print("There are unproceesed files for this given dataset")
            
            blank_file_count = 0
            blank_file_list = []
            
            for file in unprocessed_file_list:
                if header_flg == "Y":
                    file_stats = os.stat('/dbfs'+file);
                    if file_stats.st_size < 1024*1024:
                        file_df = spark_context.read.format("csv").option("inferSchema", "true").option("header","true").\
                            option("delimiter", delimeter).load(file)
                        blank_check = file_df.first()
                        if blank_check is None:
                            blank_file_flag = "Y"
                    else:
                        blank_file_flag = "N"
                elif header_flg == "N":
                    file_stats = os.stat('/dbfs'+file);
                    if file_stats.st_size < 1:
                        file_df = spark_context.read.format("csv").option("inferSchema", "true").option("header","false").\
                            option("delimiter", delimeter).load(file)
                        blank_check = file_df.first()
                        if blank_check is None:
                            blank_file_flag = "Y"
                    else:
                        blank_file_flag = "N"

                if blank_file_flag == "Y":
                    blank_file_count += 1
                    blank_file_list.append(file)
                    file_name = file.split('/')[-1]
                    new_file_name = "archive/blnk_" + str(file_name)
                    new_file_path = file.replace(file_name, new_file_name)
                    

                    query_string = "select process_id as pid from ctl_ext_dtst_master where dataset_id={dataset_id}".format(dataset_id=file_master_id)
                    query_exec = MySQLConnectionManager().execute_query_mysql(query_string)

                    process_id = 0 #default value
                    for pid in query_exec:
                        process_id = pid['pid']

                    dbutils.fs.mv(file,new_file_path)

                    log_insert_query = "insert into log_file_dtl values(-999,'{file_name}','Blank File Check','SKIPPED'," \
                                       "NOW(),NOW(),-99999,'-99999',{dataset_id},{process_id},'',0,'File is blank and " \
                                       "ingestion is skipped')".format(file_name=file,dataset_id=file_master_id,process_id=process_id)
                    MySQLConnectionManager().execute_query_mysql(log_insert_query)
                    
            if case == 1:
                print("This is a mandatory file requirement and there are no files recieved, hence proceeding to ingestion")
                return blank_file_list
            elif unprocessed_file_count == blank_file_count:
                
                print("All the unprocessed files are blank - exiting notebook with success")
                dbutils.notebook.exit("Exiting notebook with success status as there are no files available for processing")
            else:
                
                print("There are files which are not blank - proceeding to ingestion")
            return blank_file_list

        except KeyboardInterrupt:
            raise KeyboardInterrupt

        except Exception as e:
            error = ""
            self.execution_context.set_context({"traceback": error})
            logger.error(status_message, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": ""})
            raise e


    def execute_file_sanity(self, dbutils, file_master_id, spark_context=None):
        status_message = ""
        log_info = {}
        try:
            error = ""
            status_message = "Executing File Sanity Handler function of module FileSanityHandler"
            logger.debug(status_message, extra=self.execution_context.get_context())

            # Input Validations
            if file_master_id is None:
                raise Exception('File Master ID is not provided')
            self.execution_context.set_context({"file_master_id": file_master_id})
            logger.debug(status_message, extra=self.execution_context.get_context())

            # Get input location and data_set_id from MySQL table for given data source and subject area
            dataset_info = CommonUtils().get_dataset_info(file_master_id)
            source_file_location = dataset_info['file_source_location']
            header_flg = dataset_info['header_available_flag']
            delimeter = dataset_info['file_field_delimiter']
            file_pattern = dataset_info['file_name_pattern']
            file_format = dataset_info['file_format']

            #get a return of all blank files
            blank_file_list = self.blank_file_check(dbutils,file_master_id,source_file_location,header_flg,delimeter,file_pattern,spark_context)


            # Check the filed format if need any sanitization
            if file_format == "Fixed Width":
                self.convert_fixed_width_file(dbutils, file_master_id, source_file_location, header_flg, delimeter,
                                              file_pattern, spark_context)
            if file_format == "Carriage":
                self.convert_carriage_return_file(dbutils, file_master_id, source_file_location, header_flg, delimeter,
                                                  file_pattern, spark_context)
        except KeyboardInterrupt:
            raise KeyboardInterrupt

        except Exception as e:

            self.execution_context.set_context({"traceback": error})
            logger.error(status_message, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": ""})
            raise e

    def convert_fixed_width_file(self, dataset_id, source_file_location, header_flg, delimiter,
                                 spark_context=None):
        print (dataset_id, source_file_location, header_flg, delimiter)
        print("Under fixed width resolution function!")
        error = ""
        try:
            status_message = "Executing Fixed Width File Sanitization"
            logger.debug(status_message, extra=self.execution_context.get_context())
            print(str(source_file_location))

            # find the list of files
            file = source_file_location
            print("File Name Pattern Matched for file : " + file);
            # print(file_name)
            header_flag = None
            if header_flg == 'Y':
                source_df = spark_context.read.format('csv').load(file)
                source_df = source_df.withColumn("Index", monotonically_increasing_id()).filter(
                    'Index > 0').drop("Index")
                header_flag = True
            else:
                source_df = spark_context.read.format('csv').load(file)
                header_flag = False
            source_df.head(10)

            print("File read to DataFrame")
            # File read into dataframe
            configuration = JsonConfigUtility(CommonConstants.ENVIRONMENT_CONFIG_FILE)
            audit_db = configuration.get_configuration([CommonConstants.ENVIRONMENT_PARAMS_KEY, "mysql_db"])
            schema_query_str = "select column_name, column_tag  from {audit_db}.{column_metadata_table} where dataset_id={dataset_id}"
            schema_query = schema_query_str.format(audit_db=audit_db,
                                                   column_metadata_table=CommonConstants.COLUMN_METADATA_TABLE,
                                                   dataset_id=dataset_id)
            column_names_result = MySQLConnectionManager().execute_query_mysql(schema_query)
            print(column_names_result)

            print("Reading the Fixed width file into New DataFrame")
            try:
                for column in column_names_result:
                    col_length=int(json.loads(column['column_tag'])['Col_End']) - int(json.loads(column['column_tag'])['Col_Start']) + 1
                    source_df = source_df.withColumn(column['column_name'], col('_c0').substr(int(json.loads(column['column_tag'])['Col_Start']),col_length))
                new_df  = source_df.drop("_c0")
                new_df.show(2)
                
            except Exception as e:
                error = "ERROR while reading the file. Column metadata entries are not configured properly"
                print(error)
                self.execution_context.set_context({"traceback": error})
                logger.error(error, extra=self.execution_context.get_context())
                raise e
            for column in column_names_result:
                new_df = new_df.withColumn(column['column_name'], trim(col(column['column_name'])))

            hdfs_file_location='hdfs:/temp/{table_name}/'.format(table_name=source_file_location.split('/')[-4])
            print ('hdfsfilelocation ===='+str(hdfs_file_location))
            new_df.repartition(1).write.format('csv').option('header',header_flag).option("delimiter",delimiter).option('compression','gzip').mode('overwrite').option('sep',',').save(hdfs_file_location)
            
            subprocess.run('hdfs dfs -chmod 777 /', shell = True)
            
            #change hdfs file name
            out = subprocess.run('hdfs dfs -mv /temp/{table_name}/part* /temp/{table_name}/{file_name}'.format(table_name=source_file_location.split('/')[-4],file_name=source_file_location.split('/')[-1]), shell = True, stdout=subprocess.PIPE)
            
            logger.info(out.stdout, extra=self.execution_context.get_context())
            status_message = "S3 command result : " + str(out.stdout)
            logger.debug(status_message, extra=self.execution_context.get_context())
            
            
            #Deleting existing file from S3
            session = boto3.session.Session()
            s3 = session.client('s3')
            parsed_url = urlparse(source_file_location)
            s3_bucket = parsed_url.netloc
            file_path = os.path.join(parsed_url.path, "").lstrip("/").rstrip("/")
            message_del = "DELETING THIS FILE:" + str(file_path)
            object_to_delete = {'Key':file_path}
            
            s3_cmd_result = s3.delete_objects(Bucket=s3_bucket, Delete={'Objects': [object_to_delete]})
            
            
            logger.info(message_del, extra=self.execution_context.get_context())
            status_message = "S3 command result : " + str(s3_cmd_result)
            logger.debug(status_message, extra=self.execution_context.get_context())
            
            # target_s3_path = source_file_location.split('/')[:-1]
            # target_s3_path = ('/').join(target_s3_path) + '/'
            
            hdfs_to_s3_copy_s3_dist_cp_cmd = "s3-dist-cp --src {src} --dest {tgt} --s3ServerSideEncryption".format(src=hdfs_file_location+str(source_file_location.split('/')[-1]),tgt=source_file_location)
            print (hdfs_to_s3_copy_s3_dist_cp_cmd)
            print ('New File Placed to S3')
            out = subprocess.run(hdfs_to_s3_copy_s3_dist_cp_cmd,shell=True, stdout=subprocess.PIPE)
            
            logger.info(out.stdout, extra=self.execution_context.get_context())
            status_message = "S3 command result : " + str(out.stdout)
            logger.debug(status_message, extra=self.execution_context.get_context())
            
            # CommonUtils().copy_hdfs_to_s3("compute_us_comm_HBVdw.STG_IQVIA_NON_RTL_SLS_HBV_HIST")
            

        except KeyboardInterrupt:
            raise KeyboardInterrupt

        except Exception as e:

            self.execution_context.set_context({"traceback": error})
            logger.error(status_message, extra=self.execution_context.get_context())
            self.execution_context.set_context({"traceback": ""})
            raise e
